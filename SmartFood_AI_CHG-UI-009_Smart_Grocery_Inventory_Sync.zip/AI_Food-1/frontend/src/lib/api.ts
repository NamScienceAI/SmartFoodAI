export type User = { id: number; username: string };
export type Household = { id: number; name: string; owner_id?: number; members?: { id: number; username: string }[] };
export type SessionSnapshot = { user: User; household: Household | null };
export type Batch = {
  id: number;
  product_id: number;
  name: string;
  base_unit: string;
  received: string;
  expiry: string | null;
  expiry_source: "label" | "user" | "estimate" | "unknown";
  flagged: number | boolean;
  ticks: string;
  version: number;
};
export type CatalogProduct = { id: number; name: string; category: string; base_unit: string };
export type CatalogLookup = { matches: CatalogProduct[]; suggestions: CatalogProduct[] };
export type Alert = {
  batch_id: number;
  product: string;
  reason: "past_date" | "due_soon" | "verify_expiry" | "flagged";
  expiry: string | null;
  source: string;
  read: boolean;
};

let actorId: number | null = null;
export function setActor(id: number | null) { actorId = id; }

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export async function api<T>(path: string, method = "GET", body?: unknown): Promise<T> {
  const headers: Record<string, string> = { "X-SmartFood": "1" };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (actorId !== null && method !== "GET") headers["X-SmartFood-Actor"] = String(actorId);
  const response = await fetch(`/api${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    cache: "no-store",
    credentials: "same-origin",
  });
  let data: unknown = {};
  try { data = await response.json(); } catch { /* empty response */ }
  if (!response.ok) {
    const detail = typeof data === "object" && data !== null && "detail" in data
      ? String((data as { detail: unknown }).detail)
      : "Không thể hoàn thành yêu cầu.";
    throw new ApiError(detail, response.status);
  }
  return data as T;
}

export function dateLabel(value: string | null | undefined) {
  if (!value) return "Chưa xác định";
  const date = new Date(`${value}T00:00:00`);
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" }).format(date);
}

export function daysUntil(value: string | null | undefined) {
  if (!value) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(`${value}T00:00:00`);
  return Math.round((expiry.getTime() - today.getTime()) / 86_400_000);
}

export function batchState(batch: Batch) {
  if (!batch.expiry || batch.expiry_source === "unknown") return { label: "Chưa xác định hạn", tone: "neutral" as const };
  if (batch.expiry_source === "estimate") return { label: "Cần xác minh hạn", tone: "warning" as const };
  const days = daysUntil(batch.expiry);
  if (days !== null && days < 0) return { label: "Quá ngày hạn", tone: "danger" as const };
  if (days === 0) return { label: "Hết hạn hôm nay", tone: "warning" as const };
  if (days !== null && days <= 3) return { label: `Còn ${days} ngày`, tone: "warning" as const };
  return { label: "Còn hạn", tone: "success" as const };
}

export function alertLabel(alert: Alert) {
  if (alert.reason === "past_date") return "Đã quá ngày hạn";
  if (alert.reason === "due_soon") {
    const days = daysUntil(alert.expiry);
    return days === 0 ? "Hết hạn hôm nay" : `Còn ${days ?? "?"} ngày`;
  }
  if (alert.reason === "verify_expiry") return "Cần xác minh hạn";
  return "Lô đã được đánh dấu";
}

export async function uploadReceipt(path: string, file: File) {
  const response = await fetch(`/api${path}`, {
    method: "POST",
    headers: { "X-SmartFood": "1", "Content-Type": file.type },
    body: file,
    cache: "no-store",
    credentials: "same-origin",
  });
  let data: unknown = {};
  try { data = await response.json(); } catch { /* empty response */ }
  if (!response.ok) {
    const detail = typeof data === "object" && data !== null && "detail" in data
      ? String((data as { detail: unknown }).detail)
      : "Không thể xử lý hóa đơn.";
    throw new ApiError(detail, response.status);
  }
  return data as ReceiptDraft;
}

export type ReceiptSuggestion = {
  name: string;
  quantity: string;
  unit: string;
  id?: number;
  category?: string;
  base_unit?: string;
};
export type ReceiptDraft = {
  id: number;
  status: string;
  lines: string[];
  language?: string;
  suggestions: ReceiptSuggestion[];
  items: Array<Record<string, unknown>>;
  version: number;
  possible_duplicates: number[];
  confirmed?: unknown;
};
