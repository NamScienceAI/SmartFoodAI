import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SmartFood AI · Quản lý thực phẩm thông minh",
  description: "Quản lý kho thực phẩm gia đình, theo dõi hạn sử dụng và giảm lãng phí với SmartFood AI.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="vi"><body>{children}</body></html>;
}
