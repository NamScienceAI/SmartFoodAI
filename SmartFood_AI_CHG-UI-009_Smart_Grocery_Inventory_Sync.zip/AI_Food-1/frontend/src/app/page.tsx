import SmartFoodApp from "@/components/smartfood-app";

export default function Home() {
  return <SmartFoodApp />;
}
