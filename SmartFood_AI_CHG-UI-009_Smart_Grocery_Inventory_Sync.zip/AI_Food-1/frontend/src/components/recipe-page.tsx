"use client";

import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import { CalendarPlus, ChefHat, Check, CheckCircle2, Heart, Leaf, LoaderCircle, ShieldCheck, ShoppingBasket, Sparkles, Users, X } from "lucide-react";
import { api, Batch } from "@/lib/api";

type Ingredient = { product_id: number; name: string; base_unit: string; ticks_per_serving: number };
type Recipe = { id: number; name: string; allergens: string[]; tags: string[]; complete: number | boolean; source?: string; ingredients: Ingredient[] };
type DietaryProfile = { allergens: string[]; required_tags: string[]; liked_products: number[] };
type Missing = { product_id: number; unit: string; ticks: string };
type Recommendation = { recipe_id: number; name: string; score: number; coverage: number; soon_coverage: number; missing: Missing[] };
type RecommendationResponse = { method: "content" | "multi"; recipes: Recommendation[]; reason: string | null };

const ALLERGENS = ["trứng", "sữa", "đậu phộng", "đậu nành", "lúa mì", "hải sản", "mè", "hạt cây"];
const TAG_LABELS: Record<string, string> = { chay: "Ăn chay", vegan: "Thuần chay", "ít đường": "Ít đường", "ít muối": "Ít muối", "ít tinh bột": "Ít tinh bột" };
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
const amountLabel = (ticks: string | number, unit: string) => {
  const value = Number(ticks) / (unit === "quả" ? 1 : 1000);
  return `${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 2 }).format(value)} ${unit}`;
};

export default function RecipePage({ householdId, userId, batches, notify, onPlanSaved }: {
  householdId: number; userId: number; batches: Batch[]; notify: (message: string, error?: boolean) => void; onPlanSaved: () => void;
}) {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [profile, setProfile] = useState<DietaryProfile>({ allergens: [], required_tags: [], liked_products: [] });
  const [hasProfile, setHasProfile] = useState(false);
  const [servings, setServings] = useState(2);
  const [method, setMethod] = useState<"multi" | "content">("multi");
  const [results, setResults] = useState<Recommendation[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [recommending, setRecommending] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [planOpen, setPlanOpen] = useState(false);
  const [savingPlan, setSavingPlan] = useState(false);

  useEffect(() => {
    let active = true;
    Promise.all([api<Recipe[]>("/recipes"), api<DietaryProfile | null>("/me/dietary")])
      .then(([recipeData, dietary]) => {
        if (!active) return;
        setRecipes(recipeData);
        if (dietary) { setProfile(dietary); setHasProfile(true); }
        else setShowProfile(true);
      })
      .catch(error => { if (active) notify(error instanceof Error ? error.message : "Không thể tải dữ liệu món ăn.", true); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [notify]);

  const productOptions = useMemo(() => {
    const unique = new Map<number, { id: number; name: string; unit: string }>();
    recipes.forEach(recipe => recipe.ingredients.forEach(item => unique.set(item.product_id, { id: item.product_id, name: item.name, unit: item.base_unit })));
    return [...unique.values()].sort((a, b) => a.name.localeCompare(b.name, "vi"));
  }, [recipes]);
  const tagOptions = useMemo(() => [...new Set(recipes.flatMap(recipe => recipe.tags))].sort(), [recipes]);
  const filteredResults = useMemo(() => results.filter(result => result.name.toLocaleLowerCase("vi").includes(query.trim().toLocaleLowerCase("vi"))), [results, query]);
  const selected = recipes.find(recipe => recipe.id === selectedId) || null;
  const selectedResult = results.find(result => result.recipe_id === selectedId) || null;
  const availableLots = batches.filter(batch => Number(batch.ticks) > 0).length;

  const toggle = (key: "allergens" | "required_tags", value: string) => setProfile(current => ({ ...current, [key]: current[key].includes(value) ? current[key].filter(item => item !== value) : [...current[key], value] }));
  const saveProfile = async () => {
    setSavingProfile(true);
    try {
      const saved = await api<DietaryProfile>("/me/dietary", "PUT", profile);
      setProfile(saved); setHasProfile(true); setShowProfile(false);
      notify("Đã lưu hồ sơ ăn uống và các lựa chọn an toàn.");
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể lưu hồ sơ ăn uống.", true); }
    finally { setSavingProfile(false); }
  };

  const recommend = async () => {
    if (!hasProfile) { setShowProfile(true); notify("Hãy hoàn thiện hồ sơ ăn uống trước khi nhận gợi ý."); return; }
    setRecommending(true);
    try {
      const response = await api<RecommendationResponse>(`/households/${householdId}/recommendations`, "POST", { participants: [userId], servings, method });
      setResults(response.recipes); setSelectedId(response.recipes[0]?.recipe_id ?? null);
      if (!response.recipes.length) notify(response.reason || "Chưa tìm thấy món phù hợp với điều kiện hiện tại.");
      else notify(`Đã tìm thấy ${response.recipes.length} món phù hợp từ dữ liệu kho.`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Không thể tạo gợi ý món ăn.";
      if (message.toLocaleLowerCase("vi").includes("thông tin ăn uống")) setShowProfile(true);
      notify(message, true);
    } finally { setRecommending(false); }
  };

  const saveMeal = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedResult) return;
    const form = new FormData(event.currentTarget);
    setSavingPlan(true);
    try {
      await api(`/households/${householdId}/meals`, "POST", {
        request_key: crypto.randomUUID(), recipe_id: selectedResult.recipe_id, day: String(form.get("day")),
        meal: String(form.get("meal")), servings, participants: [userId],
      });
      setPlanOpen(false); notify("Đã thêm món vào kế hoạch bữa ăn. Nguyên liệu thiếu sẽ được tính trong danh sách mua sắm."); onPlanSaved();
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể lưu kế hoạch bữa ăn.", true); }
    finally { setSavingPlan(false); }
  };

  if (loading) return <div className="recipe-loading"><LoaderCircle className="spin" size={22} /> Đang tải danh mục món ăn và hồ sơ dinh dưỡng...</div>;

  return <>
    <section className="page-heading"><span className="eyebrow">SMARTFOOD AI · TRỢ LÝ BẾP</span><h1>Gợi ý món ăn thông minh</h1><p>Khám phá món ăn dựa trên nguyên liệu đang có, khẩu phần và hồ sơ ăn uống của bạn.</p></section>
    <div className="recipe-hero">
      <div className="recipe-hero-copy"><span className="recipe-kicker"><Sparkles size={14} /> SMART RECIPE MATCH</span><h2>Biến nguyên liệu sẵn có<br/><em>thành bữa ăn ngon.</em></h2><p>Ưu tiên tận dụng thực phẩm trong kho và nguyên liệu gần đến hạn, đồng thời tôn trọng hồ sơ dị ứng đã khai báo.</p>
        <div className="recipe-hero-meta"><span><Leaf size={14}/> {availableLots} lô thực phẩm trong kho</span><span><ShieldCheck size={14}/> Lọc theo hồ sơ ăn uống</span></div>
      </div>
      <div className="recipe-hero-art"><div className="recipe-orbit orbit-a"/><div className="recipe-orbit orbit-b"/><div className="recipe-bowl">🥗</div><span className="recipe-float float-a">🥕</span><span className="recipe-float float-b">🥑</span><span className="recipe-float float-c">🍅</span></div>
    </div>

    <section className="recipe-control-grid">
      <article className="surface-card recipe-control-card"><div className="recipe-section-title"><div><span className="eyebrow">TÙY CHỈNH GỢI Ý</span><h2>Bạn muốn nấu cho mấy người?</h2></div><span className="recipe-control-icon"><Users size={19}/></span></div>
        <div className="serving-stepper"><button onClick={() => setServings(value => Math.max(1, value - 1))} disabled={servings <= 1} aria-label="Giảm khẩu phần">−</button><strong>{servings}</strong><span>khẩu phần</span><button onClick={() => setServings(value => Math.min(100, value + 1))} disabled={servings >= 100} aria-label="Tăng khẩu phần">+</button></div>
        <label className="recipe-select-label">Phương pháp xếp hạng<select value={method} onChange={event => setMethod(event.target.value as "multi" | "content")}><option value="multi">Kết hợp · Ưu tiên hạn gần và độ sẵn có</option><option value="content">Theo sở thích và độ phù hợp nguyên liệu</option></select></label>
        <div className="recipe-control-actions"><button className="btn btn-primary" onClick={recommend} disabled={recommending || !hasProfile}><Sparkles size={16}/>{recommending ? "Đang phân tích..." : "Tìm món phù hợp"}</button><button className="btn btn-outline" onClick={() => setShowProfile(value => !value)}><ShieldCheck size={15}/> Hồ sơ ăn uống</button></div>
        {!hasProfile && <p className="recipe-inline-warning"><ShieldCheck size={14}/> Cần khai báo hồ sơ ăn uống để hệ thống lọc món an toàn.</p>}
      </article>
      <article className="surface-card recipe-how-card"><div className="recipe-section-title"><div><span className="eyebrow">CÁCH ĐỀ XUẤT</span><h2>Gợi ý có căn cứ</h2></div><span className="recipe-control-icon"><CheckCircle2 size={19}/></span></div><div className="recipe-how-list"><div><span>01</span><p><b>Đối chiếu tồn kho</b><small>Kiểm tra lượng nguyên liệu có thể sử dụng.</small></p></div><div><span>02</span><p><b>Ưu tiên hạn gần</b><small>Phương pháp kết hợp cộng điểm cho nguyên liệu sắp đến hạn.</small></p></div><div><span>03</span><p><b>Lọc chế độ ăn</b><small>Loại món không phù hợp dị ứng và nhãn ăn uống đã khai báo.</small></p></div></div></article>
    </section>

    {showProfile && <section className="surface-card dietary-card"><div className="recipe-section-title"><div><span className="eyebrow">CÁ NHÂN HÓA & AN TOÀN</span><h2>Hồ sơ ăn uống</h2><p>Thông tin này được dùng để lọc món cho tài khoản hiện tại.</p></div><button className="icon-button" onClick={() => setShowProfile(false)} aria-label="Đóng"><X size={17}/></button></div>
      <div className="dietary-block"><b>Thành phần cần tránh</b><small>Chọn các nhóm dị ứng áp dụng cho bạn.</small><div className="dietary-chips">{ALLERGENS.map(item => <button key={item} className={profile.allergens.includes(item) ? "active" : ""} onClick={() => toggle("allergens", item)}>{profile.allergens.includes(item) && <Check size={13}/>} {item}</button>)}</div></div>
      <div className="dietary-block"><b>Chế độ ăn mong muốn</b><small>Chỉ các nhãn có trong danh mục công thức mới được áp dụng.</small><div className="dietary-chips">{tagOptions.map(item => <button key={item} className={profile.required_tags.includes(item) ? "active" : ""} onClick={() => toggle("required_tags", item)}>{profile.required_tags.includes(item) && <Check size={13}/>} {TAG_LABELS[item] || item}</button>)}</div>{!tagOptions.length && <p className="recipe-muted">Danh mục công thức chưa có nhãn chế độ ăn.</p>}</div>
      <div className="dietary-block"><b>Nguyên liệu yêu thích</b><small>Các lựa chọn này giúp tăng điểm phù hợp cho món có chứa nguyên liệu bạn thích.</small><div className="dietary-favorites">{productOptions.map(item => <label key={item.id}><input type="checkbox" checked={profile.liked_products.includes(item.id)} onChange={() => setProfile(current => ({ ...current, liked_products: current.liked_products.includes(item.id) ? current.liked_products.filter(id => id !== item.id) : [...current.liked_products, item.id] }))}/><span>{item.name}</span></label>)}</div></div>
      <div className="recipe-profile-footer"><span><ShieldCheck size={14}/> Không thay thế tư vấn y tế hoặc kiểm tra nhãn thực phẩm.</span><button className="btn btn-primary" onClick={saveProfile} disabled={savingProfile}>{savingProfile ? "Đang lưu..." : "Lưu hồ sơ"}<CheckCircle2 size={15}/></button></div>
    </section>}

    <section className="recipe-results-section"><div className="recipe-results-heading"><div><span className="eyebrow">KẾT QUẢ PHÂN TÍCH</span><h2>Món ăn phù hợp với bạn</h2><p>{results.length ? `${results.length} công thức được xếp hạng từ danh mục hiện có.` : "Thiết lập khẩu phần và bấm tìm món để bắt đầu."}</p></div>{results.length > 0 && <div className="recipe-search"><span>⌕</span><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Tìm món ăn..."/></div>}</div>
      {!results.length ? <div className="surface-card recipe-empty"><div><ChefHat size={29}/></div><b>Chưa có đề xuất nào</b><p>Hãy lưu hồ sơ ăn uống và bắt đầu phân tích để tìm món phù hợp với kho thực phẩm.</p></div> : <div className="recipe-results-layout"><div className="recipe-result-list">{filteredResults.map((item, index) => { const recipe = recipes.find(r => r.id === item.recipe_id); const isSelected = selectedId === item.recipe_id; return <button key={item.recipe_id} className={`recipe-result-card ${isSelected ? "selected" : ""}`} onClick={() => setSelectedId(item.recipe_id)}><span className="recipe-rank">{String(index + 1).padStart(2, "0")}</span><span className="recipe-result-emoji">{recipe?.tags.includes("chay") ? "🥬" : "🍲"}</span><span className="recipe-result-copy"><b>{item.name}</b><small>{recipe?.tags.length ? recipe.tags.map(tag => TAG_LABELS[tag] || tag).join(" · ") : "Món ăn gia đình"}</small><span className="recipe-mini-progress"><i style={{ width: `${Math.round(item.coverage * 100)}%` }}/></span></span><span className="recipe-match"><b>{Math.round(item.score * 100)}%</b><small>phù hợp</small></span></button>; })}{!filteredResults.length && <div className="recipe-no-match">Không tìm thấy món theo từ khóa này.</div>}</div>
      {selected && selectedResult && <article className="surface-card recipe-detail-card"><div className="recipe-detail-top"><span className="recipe-detail-emoji">{selected.tags.includes("chay") ? "🥬" : "🍲"}</span><div><span className="eyebrow">CÔNG THỨC #{selected.id}</span><h3>{selected.name}</h3><div className="recipe-tag-row">{selected.tags.map(tag => <span key={tag}>{TAG_LABELS[tag] || tag}</span>)}{selected.allergens.map(tag => <span className="allergen" key={tag}>Có {tag}</span>)}</div></div></div>
        <div className="recipe-coverage"><div><span>Mức đáp ứng nguyên liệu</span><b>{Math.round(selectedResult.coverage * 100)}%</b></div><div className="recipe-progress"><i style={{ width: `${Math.round(selectedResult.coverage * 100)}%` }}/></div><small>{selectedResult.missing.length ? `Còn thiếu ${selectedResult.missing.length} loại nguyên liệu.` : "Bạn đã có đủ nguyên liệu theo dữ liệu tồn kho."}</small></div>
        <div className="recipe-ingredients-heading"><b>Nguyên liệu cho {servings} khẩu phần</b><span>{selected.ingredients.length} thành phần</span></div><div className="recipe-ingredient-list">{selected.ingredients.map(item => { const need = item.ticks_per_serving * servings; const missing = selectedResult.missing.find(m => m.product_id === item.product_id); return <div key={item.product_id}><span className={`ingredient-check ${missing ? "missing" : ""}`}>{missing ? <ShoppingBasket size={13}/> : <Check size={13}/>}</span><span><b>{item.name}</b><small>{amountLabel(need, item.base_unit)} cần dùng</small></span><em className={missing ? "missing-text" : "available-text"}>{missing ? "Cần bổ sung" : "Đủ trong kho"}</em></div>; })}</div>
        {selectedResult.missing.length > 0 && <div className="recipe-missing-note"><ShoppingBasket size={15}/><span>Nguyên liệu còn thiếu sẽ được tính vào danh sách mua sắm sau khi bạn lập kế hoạch bữa ăn.</span></div>}
        <div className="recipe-detail-actions"><button className="btn btn-primary" onClick={() => setPlanOpen(true)}><CalendarPlus size={16}/> Lên kế hoạch bữa ăn</button><span><Heart size={14}/> Điểm phù hợp dựa trên hồ sơ và dữ liệu kho</span></div>
        <p className="recipe-source-note">Công thức hiện có cung cấp tên món, nhãn và định lượng nguyên liệu; hướng dẫn chế biến chi tiết chưa có trong danh mục dữ liệu.</p>
      </article>}</div>}
    </section>

    {planOpen && selectedResult && <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) setPlanOpen(false); }}><section className="inventory-modal" role="dialog" aria-modal="true" aria-labelledby="recipe-plan-title"><div className="modal-heading"><div><span className="eyebrow">KẾ HOẠCH BỮA ĂN</span><h2 id="recipe-plan-title">Thêm {selectedResult.name}</h2><p>{servings} khẩu phần · Nguyên liệu thiếu sẽ được tính vào nhu cầu mua sắm.</p></div><button className="icon-button" onClick={() => setPlanOpen(false)} aria-label="Đóng"><X size={18}/></button></div><form className="inventory-form" onSubmit={saveMeal}><label>Ngày thực hiện<input type="date" name="day" min={today()} defaultValue={today()} required/></label><label>Bữa ăn<select name="meal" defaultValue="trưa"><option value="sáng">Bữa sáng</option><option value="trưa">Bữa trưa</option><option value="tối">Bữa tối</option><option value="phụ">Bữa phụ</option></select></label><div className="modal-actions"><button type="button" className="btn btn-outline" onClick={() => setPlanOpen(false)}>Hủy</button><button className="btn btn-primary" disabled={savingPlan}>{savingPlan ? "Đang lưu..." : "Lưu kế hoạch"}<CalendarPlus size={15}/></button></div></form></section></div>}
  </>;
}
