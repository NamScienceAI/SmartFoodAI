"use client";

import { useMemo, useState } from "react";
import { AlertTriangle, Check, CheckCircle2, ChevronRight, FileImage, LoaderCircle, Plus, Search, ShieldCheck, Trash2, UploadCloud, X } from "lucide-react";
import { api, CatalogLookup, CatalogProduct, ReceiptDraft, ReceiptSuggestion, uploadReceipt } from "@/lib/api";

type ReceiptRow = {
  key: string;
  requestKey: string;
  sourceName: string;
  sourceUnit: string;
  product: CatalogProduct | null;
  query: string;
  quantity: string;
  unit: string;
  received: string;
  expiry: string;
  expirySource: "label" | "user" | "estimate" | "unknown";
  lookup: CatalogLookup;
  searching: boolean;
};

const today = () => new Date().toLocaleDateString("en-CA");
const supportedUnits = ["g", "kg", "ml", "l", "quả"];
function unitsFor(product: CatalogProduct | null) {
  if (!product) return supportedUnits;
  if (product.base_unit === "g") return ["g", "kg"];
  if (product.base_unit === "ml") return ["ml", "l"];
  return ["quả"];
}

function rowFromSuggestion(item: ReceiptSuggestion, index: number): ReceiptRow {
  const product = item.id ? { id: item.id, name: item.name, category: item.category || "Thực phẩm", base_unit: item.base_unit || item.unit } : null;
  const parsedUnit = supportedUnits.includes(item.unit) ? item.unit : "";
  const unit = product && !unitsFor(product).includes(parsedUnit) ? product.base_unit : parsedUnit;
  return {
    key: `ocr-${index}-${item.name}`,
    requestKey: crypto.randomUUID(),
    sourceName: item.name,
    sourceUnit: item.unit,
    product,
    query: item.name,
    quantity: item.quantity,
    unit,
    received: today(),
    expiry: "",
    expirySource: "unknown",
    lookup: { matches: product ? [product] : [], suggestions: [] },
    searching: false,
  };
}

export default function ReceiptPage({ householdId, onImported, notify }: { householdId: number; onImported: () => Promise<void>; notify: (message: string, error?: boolean) => void }) {
  const [draft, setDraft] = useState<ReceiptDraft | null>(null);
  const [rows, setRows] = useState<ReceiptRow[]>([]);
  const [fileName, setFileName] = useState("");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [showRawLines, setShowRawLines] = useState(false);

  const mappedCount = useMemo(() => rows.filter(row => row.product && row.quantity.trim() && row.unit).length, [rows]);

  const updateRow = (key: string, patch: Partial<ReceiptRow>) => setRows(current => current.map(row => row.key === key ? { ...row, ...patch } : row));

  const handleFile = async (file?: File) => {
    if (!file) return;
    if (!(["image/jpeg", "image/png"].includes(file.type))) { notify("Chỉ hỗ trợ ảnh PNG hoặc JPEG.", true); return; }
    if (file.size > 5 * 1024 * 1024) { notify("Ảnh hóa đơn vượt giới hạn 5 MiB.", true); return; }
    setUploading(true);
    setFileName(file.name);
    setDraft(null);
    setRows([]);
    try {
      const result = await uploadReceipt(`/households/${householdId}/receipts`, file);
      setDraft(result);
      setRows(result.suggestions.map(rowFromSuggestion));
      if (result.possible_duplicates?.length) notify(`Lưu ý: ảnh này có thể trùng hóa đơn #${result.possible_duplicates.join(", #")}.`);
      else notify("Đã nhận diện hóa đơn. Hãy kiểm tra và chỉnh sửa từng dòng trước khi nhập kho.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không thể quét hóa đơn.", true);
    } finally { setUploading(false); }
  };

  const searchProduct = async (key: string, query: string) => {
    updateRow(key, { query, product: null, searching: Boolean(query.trim()), lookup: { matches: [], suggestions: [] } });
    if (!query.trim()) return;
    try {
      const result = await api<CatalogLookup>(`/catalog/products?q=${encodeURIComponent(query.trim())}`);
      setRows(current => current.map(row => row.key === key && row.query === query ? { ...row, lookup: result, searching: false } : row));
    } catch (error) {
      setRows(current => current.map(row => row.key === key ? { ...row, searching: false } : row));
      notify(error instanceof Error ? error.message : "Không thể tìm danh mục.", true);
    }
  };

  const addManualRow = () => {
    setRows(current => [...current, { key: `manual-${Date.now()}-${current.length}`, requestKey: crypto.randomUUID(), sourceName: "", sourceUnit: "", product: null, query: "", quantity: "1", unit: "quả", received: today(), expiry: "", expirySource: "unknown", lookup: { matches: [], suggestions: [] }, searching: false }]);
  };

  const saveDraft = async () => {
    if (!draft) return;
    if (draft.id === 0) { notify("Bản nhập thủ công sẽ được ghi vào kho khi bạn xác nhận."); return; }
    if (!rows.length) { notify("Hãy thêm ít nhất một dòng thực phẩm.", true); return; }
    if (rows.some(row => !row.product || !row.quantity.trim() || !row.unit || !row.received || (row.expirySource !== "unknown" && !row.expiry))) {
      notify("Vui lòng chọn sản phẩm trong danh mục và hoàn thiện số lượng, đơn vị, ngày nhận, hạn sử dụng.", true); return;
    }
    setSaving(true);
    try {
      const items = rows.map(row => ({
        product_id: row.product!.id,
        quantity: row.quantity,
        unit: row.unit,
        received: row.received,
        expiry: row.expirySource === "unknown" ? null : row.expiry,
        expiry_source: row.expirySource,
        flagged: false,
      }));
      const updated = await api<ReceiptDraft>(`/households/${householdId}/receipts/${draft.id}`, "PUT", { version: draft.version, items });
      setDraft(current => current ? { ...current, ...updated } : current);
      notify("Đã lưu bản nháp. Bạn có thể xác nhận nhập kho.");
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể lưu bản nháp.", true); }
    finally { setSaving(false); }
  };

  const confirmImport = async () => {
    if (!draft) return;
    if (mappedCount !== rows.length || !rows.length) { notify("Còn dòng chưa được ghép với danh mục hoặc thiếu thông tin.", true); return; }
    setConfirming(true);
    try {
      // Bản nhập thủ công không có receipt ID; ghi từng lô qua API kho với khóa idempotency riêng.
      const items = rows.map(row => ({ product_id: row.product!.id, quantity: row.quantity, unit: row.unit, received: row.received, expiry: row.expirySource === "unknown" ? null : row.expiry, expiry_source: row.expirySource, flagged: false }));
      if (draft.id === 0) {
        for (const [index, item] of items.entries()) await api(`/households/${householdId}/inventory/batches`, "POST", { ...item, request_key: rows[index].requestKey });
      } else {
        let currentDraft = draft;
        if (draft.items.length === 0 || JSON.stringify(draft.items) !== JSON.stringify(items)) {
          currentDraft = await api<ReceiptDraft>(`/households/${householdId}/receipts/${draft.id}`, "PUT", { version: draft.version, items });
          setDraft(currentDraft);
        }
        await api(`/households/${householdId}/receipts/${draft.id}/confirm`, "POST", { version: currentDraft.version, request_key: crypto.randomUUID() });
      }
      await onImported();
      notify("Nhập kho thành công!");
      setDraft(null); setRows([]); setFileName("");
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể xác nhận nhập kho.", true); }
    finally { setConfirming(false); }
  };

  return <>
    <header className="page-heading"><span className="eyebrow">NHẬP KHO THÔNG MINH</span><h1>Quét hóa đơn</h1><p>Tải ảnh hóa đơn, để SmartFood nhận diện dòng hàng, sau đó kiểm tra và xác nhận trước khi nhập kho.</p></header>
    <div className="receipt-security"><ShieldCheck size={17} /><span>Không có dòng hàng nào được nhập kho tự động. Bạn luôn kiểm tra và xác nhận trước khi cập nhật tồn kho.</span></div>
    {!draft ? <section className="receipt-upload-card surface-card">
      <div className="receipt-upload-icon"><FileImage size={27} /></div>
      <h2>Đưa hóa đơn vào SmartFood AI</h2>
      <p>Chọn ảnh chụp rõ nét, đủ sáng và không bị cắt mất tên hàng hoặc số lượng.</p>
      <label className={`receipt-dropzone ${uploading ? "is-loading" : ""}`}>
        <input type="file" accept="image/png,image/jpeg" disabled={uploading} onChange={event => { void handleFile(event.target.files?.[0]); event.currentTarget.value = ""; }} />
        {uploading ? <><LoaderCircle className="spin" size={28} /><b>Đang đọc hóa đơn...</b><small>{fileName}</small></> : <><UploadCloud size={30} /><b>Kéo thả hoặc nhấn để tải ảnh</b><small>Định dạng PNG, JPEG · Tối đa 5 MiB</small></>}
      </label>
      <div className="receipt-upload-foot"><span><CheckCircle2 size={14} /> Nhận diện văn bản OCR</span><span><CheckCircle2 size={14} /> Đối chiếu danh mục thực phẩm</span><span><CheckCircle2 size={14} /> Xác nhận trước khi nhập kho</span></div>
      <div className="receipt-manual"><span>Ảnh không đọc được?</span><button className="inline-link" onClick={() => { setDraft({ id: 0, status: "manual", lines: [], suggestions: [], items: [], version: 1, possible_duplicates: [] }); setRows([]); }}>Nhập dòng hàng thủ công <ChevronRight size={14} /></button></div>
    </section> : <section className="receipt-review surface-card">
      <div className="receipt-review-heading"><div><span className="eyebrow">BƯỚC 2 · KIỂM TRA DỮ LIỆU</span><h2>{fileName || "Nhập thực phẩm"}</h2><p>{draft.id ? `Mã hóa đơn #${draft.id} · Phiên bản ${draft.version}` : "Bản nhập thủ công"}</p></div><button className="icon-button" aria-label="Hủy hóa đơn" onClick={() => { setDraft(null); setRows([]); setFileName(""); }}><X size={18} /></button></div>
      {draft.possible_duplicates?.length > 0 && <div className="receipt-warning"><AlertTriangle size={17} /> Có thể trùng với hóa đơn: #{draft.possible_duplicates.join(", #")}. Hãy kiểm tra trước khi xác nhận.</div>}
      {draft.lines.length > 0 && <div className="receipt-ocr-lines"><button className="inline-link" onClick={() => setShowRawLines(value => !value)}>{showRawLines ? "Ẩn" : "Xem"} nội dung OCR gốc ({draft.lines.length} dòng)</button>{showRawLines && <ul>{draft.lines.map((line, index) => <li key={index}>{line}</li>)}</ul>}</div>}
      {rows.length === 0 && <div className="receipt-empty"><FileImage size={24} /><b>Chưa nhận diện được dòng hàng phù hợp</b><span>Bạn có thể thêm dòng và chọn thực phẩm từ danh mục.</span></div>}
      <div className="receipt-rows">{rows.map((row, index) => <article className="receipt-row" key={row.key}>
        <div className="receipt-row-top"><span className="receipt-row-index">{String(index + 1).padStart(2, "0")}</span><div><b>{row.sourceName || "Dòng hàng mới"}</b><small>{row.product ? `Đã ghép: ${row.product.name}` : "Cần đối chiếu danh mục"}</small></div><button className="icon-button danger-icon" title="Xóa dòng" onClick={() => setRows(current => current.filter(item => item.key !== row.key))}><Trash2 size={15} /></button></div>
        <div className="receipt-product-search"><Search size={15} /><input value={row.query} onChange={event => void searchProduct(row.key, event.target.value)} placeholder="Tìm và chọn thực phẩm trong danh mục" />{row.searching && <LoaderCircle className="spin" size={15} />}</div>
        {(row.lookup.matches.length || row.lookup.suggestions.length) > 0 && !row.product && <div className="receipt-product-options">{(row.lookup.matches.length ? row.lookup.matches : row.lookup.suggestions).slice(0, 6).map(product => <button key={product.id} onClick={() => updateRow(row.key, { product, query: product.name, unit: unitsFor(product).includes(row.unit) ? row.unit : product.base_unit, lookup: { matches: [product], suggestions: [] } })}><span><b>{product.name}</b><small>{product.category} · Đơn vị chuẩn {product.base_unit}</small></span><ChevronRight size={15} /></button>)}</div>}
        {row.product && <div className="receipt-selected-product"><Check size={14} /> {row.product.name}<button onClick={() => updateRow(row.key, { product: null })}>Đổi</button></div>}
        <div className="receipt-fields"><label>Số lượng<input type="number" min="0.001" step="any" value={row.quantity} onChange={event => updateRow(row.key, { quantity: event.target.value })} /></label><label>Đơn vị<select value={row.unit} onChange={event => updateRow(row.key, { unit: event.target.value })}><option value="">Chọn đơn vị</option>{unitsFor(row.product).map(unit => <option key={unit} value={unit}>{unit}</option>)}</select></label><label>Ngày nhập<input type="date" max={today()} value={row.received} onChange={event => updateRow(row.key, { received: event.target.value })} /></label><label>Nguồn hạn sử dụng<select value={row.expirySource} onChange={event => updateRow(row.key, { expirySource: event.target.value as ReceiptRow["expirySource"] })}><option value="unknown">Chưa xác định</option><option value="label">Theo nhãn sản phẩm</option><option value="user">Người dùng xác nhận</option><option value="estimate">Ước tính – cần xác minh</option></select></label></div>
        {row.expirySource !== "unknown" && <label className="receipt-expiry">Hạn sử dụng<input type="date" value={row.expiry} onChange={event => updateRow(row.key, { expiry: event.target.value })} /></label>}
        {(!row.unit || (row.sourceUnit && (!supportedUnits.includes(row.sourceUnit) || (row.product && !unitsFor(row.product).includes(row.sourceUnit))))) && <small className="receipt-row-hint">{row.sourceUnit ? `OCR đọc đơn vị “${row.sourceUnit}”. Hãy kiểm tra và tự quy đổi số lượng sang đơn vị tương thích với danh mục trước khi nhập kho.` : "Hãy chọn đơn vị tương ứng với sản phẩm trong danh mục."}</small>}
      </article>)}</div>
      <div className="receipt-add-row"><button className="btn btn-outline" onClick={addManualRow}><Plus size={16} /> Thêm dòng thực phẩm</button><span>{mappedCount}/{rows.length} dòng đã sẵn sàng</span></div>
      <div className="receipt-review-footer">{draft.id !== 0 && <button className="btn btn-outline" onClick={saveDraft} disabled={saving || confirming}>{saving ? "Đang lưu..." : "Lưu bản nháp"}</button>}<button className="btn btn-primary" onClick={confirmImport} disabled={confirming || saving || !rows.length || mappedCount !== rows.length}>{confirming ? "Đang nhập kho..." : "Xác nhận và nhập kho"}<ChevronRight size={16} /></button></div>
      <p className="receipt-disclaimer"><ShieldCheck size={14} /> Chỉ xác nhận khi tên thực phẩm, số lượng, đơn vị và hạn sử dụng đã được kiểm tra chính xác.</p>
    </section>}
  </>;
}
