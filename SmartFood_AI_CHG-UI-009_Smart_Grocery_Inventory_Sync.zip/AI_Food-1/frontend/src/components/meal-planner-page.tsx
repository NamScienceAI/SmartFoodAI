"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import {
  CalendarDays, CalendarPlus, Check, CheckCircle2, ChevronLeft, ChevronRight,
  Circle, ClipboardList, Clock3, LoaderCircle, Pencil, Plus, RefreshCw, ShoppingBasket,
  ShoppingCart, Trash2, Utensils, X, PackageCheck, ShieldCheck,
} from "lucide-react";
import { api, CatalogLookup, CatalogProduct, dateLabel } from "@/lib/api";

type View = "meals" | "groceries";
type Recipe = { id: number; name: string; allergens: string[]; tags: string[]; complete: number | boolean; ingredients: Array<{ product_id: number; name: string; base_unit: string; ticks_per_serving: number }> };
type Meal = { id: number; recipe_id: number; day: string; meal: "sáng" | "trưa" | "tối" | "phụ"; servings: number; participants: number[]; household_id: number };
type Shortage = { product_id: number; name: string; unit: string; ticks: string };
type SavedGroceryItem = { product_id: number; ticks: string; purchased: number | boolean; received_batch_id: number | null };
type SavedList = { id: number; start: string; end: string; items: SavedGroceryItem[] };

const today = () => localDate(new Date());
function localDate(date: Date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
function addDays(value: string, days: number) { const d = new Date(`${value}T12:00:00`); d.setDate(d.getDate() + days); return localDate(d); }
function mondayOf(value: string) { const d = new Date(`${value}T12:00:00`); const offset = (d.getDay() + 6) % 7; d.setDate(d.getDate() - offset); return localDate(d); }
function formatAmount(ticks: string | number, unit: string) {
  const raw = Number(ticks);
  const value = unit === "quả" ? raw : raw / 1000;
  return `${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 2 }).format(value)} ${unit}`;
}
function mealLabel(meal: Meal["meal"]) { return ({ sáng: "Bữa sáng", trưa: "Bữa trưa", tối: "Bữa tối", phụ: "Bữa phụ" })[meal]; }
function errorText(error: unknown, fallback: string) { return error instanceof Error ? error.message : fallback; }

export default function MealPlannerPage({ householdId, userId, view, onNavigate, notify, onChanged }: {
  householdId: number; userId: number; view: View; onNavigate: (view: View) => void;
  notify: (message: string, error?: boolean) => void; onChanged: () => Promise<void>;
}) {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [meals, setMeals] = useState<Meal[]>([]);
  const [products, setProducts] = useState<CatalogProduct[]>([]);
  const [savedLists, setSavedLists] = useState<SavedList[]>([]);
  const [start, setStart] = useState(() => mondayOf(today()));
  const [end, setEnd] = useState(() => addDays(mondayOf(today()), 6));
  const [shortages, setShortages] = useState<Shortage[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingMeal, setEditingMeal] = useState<Meal | null>(null);
  const [savingMeal, setSavingMeal] = useState(false);
  const [savingList, setSavingList] = useState(false);
  const [busyItem, setBusyItem] = useState<string | null>(null);
  const [receivingItem, setReceivingItem] = useState<{ listId: number; item: SavedGroceryItem; name: string; unit: string } | null>(null);
  const [savingReceive, setSavingReceive] = useState(false);
  const [search, setSearch] = useState("");

  const load = useCallback(async () => {
    const [recipeData, mealData, productData, listData] = await Promise.all([
      api<Recipe[]>("/recipes"),
      api<Meal[]>(`/households/${householdId}/meals`),
      api<CatalogLookup>("/catalog/products"),
      api<SavedList[]>(`/households/${householdId}/grocery-lists`),
    ]);
    setRecipes(recipeData);
    setMeals(mealData);
    setProducts(productData.matches || []);
    setSavedLists(listData);
  }, [householdId]);

  const loadShortages = useCallback(async () => {
    if (!start || !end || start > end) { setShortages([]); return; }
    const params = new URLSearchParams({ start, end });
    const data = await api<Shortage[]>(`/households/${householdId}/groceries?${params.toString()}`);
    setShortages(data);
  }, [householdId, start, end]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([load(), loadShortages()])
      .catch(error => { if (active) notify(errorText(error, "Không thể tải dữ liệu kế hoạch."), true); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [load, loadShortages, notify]);

  const visibleMeals = useMemo(() => meals
    .filter(item => item.day >= start && item.day <= end)
    .filter(item => !search.trim() || (recipes.find(recipe => recipe.id === item.recipe_id)?.name || "").toLocaleLowerCase("vi").includes(search.trim().toLocaleLowerCase("vi")))
    .sort((a, b) => a.day.localeCompare(b.day) || ["sáng", "trưa", "tối", "phụ"].indexOf(a.meal) - ["sáng", "trưa", "tối", "phụ"].indexOf(b.meal)), [meals, recipes, start, end, search]);
  const mealCount = visibleMeals.length;
  const plannedServings = visibleMeals.reduce((sum, meal) => sum + meal.servings, 0);
  const productMap = useMemo(() => new Map(products.map(product => [product.id, product])), [products]);
  const totalMissingTypes = shortages.length;
  const savedForRange = savedLists.filter(list => list.start === start && list.end === end);

  const refreshAll = async () => {
    setRefreshing(true);
    try { await Promise.all([load(), loadShortages()]); notify("Đã đồng bộ kế hoạch và nhu cầu mua sắm."); }
    catch (error) { notify(errorText(error, "Không thể làm mới dữ liệu."), true); }
    finally { setRefreshing(false); }
  };

  const createMeal = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const recipeId = Number(form.get("recipe_id"));
    const recipe = recipes.find(item => item.id === recipeId);
    if (!recipe) { notify("Vui lòng chọn công thức hợp lệ.", true); return; }
    setSavingMeal(true);
    try {
      const payload = {
        request_key: crypto.randomUUID(), recipe_id: recipeId, day: String(form.get("day")),
        meal: String(form.get("meal")), servings: Number(form.get("servings")), participants: [userId],
      };
      if (editingMeal) await api(`/households/${householdId}/meals/${editingMeal.id}`, "PUT", payload);
      else await api(`/households/${householdId}/meals`, "POST", payload);
      setModalOpen(false);
      setEditingMeal(null);
      await Promise.all([load(), loadShortages(), onChanged()]);
      notify("Đã thêm bữa ăn vào kế hoạch.");
    } catch (error) { notify(errorText(error, "Không thể lưu bữa ăn."), true); }
    finally { setSavingMeal(false); }
  };

  const openEditMeal = (meal: Meal) => { setEditingMeal(meal); setModalOpen(true); };
  const openCreateMeal = () => { setEditingMeal(null); setModalOpen(true); };

  const deleteMeal = async (meal: Meal) => {
    if (!window.confirm("Bạn có chắc muốn xóa bữa ăn này khỏi kế hoạch?")) return;
    setBusyItem(`meal-${meal.id}`);
    try {
      await api(`/households/${householdId}/meals/${meal.id}`, "DELETE");
      await Promise.all([load(), loadShortages()]);
      notify("Đã xóa bữa ăn khỏi kế hoạch.");
    } catch (error) { notify(errorText(error, "Không thể xóa bữa ăn."), true); }
    finally { setBusyItem(null); }
  };

  const createShoppingList = async () => {
    if (!shortages.length) { notify("Khoảng thời gian này chưa có nguyên liệu cần mua."); return; }
    setSavingList(true);
    try {
      const result = await api<{ id: number; items: Shortage[] }>(`/households/${householdId}/grocery-lists`, "POST", {
        request_key: crypto.randomUUID(), start, end, items: shortages,
      });
      await load();
      notify(`Đã tạo danh sách mua sắm gồm ${result.items.length} loại nguyên liệu.`);
    } catch (error) {
      const message = errorText(error, "Không thể tạo danh sách mua sắm.");
      if (message.includes("thay đổi")) await loadShortages();
      notify(message, true);
    } finally { setSavingList(false); }
  };

  const togglePurchased = async (listId: number, productId: number, purchased: boolean) => {
    const key = `${listId}-${productId}`;
    setBusyItem(key);
    try {
      await api(`/households/${householdId}/grocery-lists/${listId}/items/${productId}`, "PUT", { purchased });
      setSavedLists(current => current.map(list => list.id !== listId ? list : {
        ...list, items: list.items.map(item => item.product_id === productId ? { ...item, purchased } : item),
      }));
    } catch (error) { notify(errorText(error, "Không thể cập nhật trạng thái mua."), true); }
    finally { setBusyItem(null); }
  };

  const openReceive = (listId: number, item: SavedGroceryItem) => {
    const product = productMap.get(item.product_id);
    setReceivingItem({ listId, item, name: product?.name || `Thực phẩm #${item.product_id}`, unit: product?.base_unit || "g" });
  };

  const confirmReceive = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!receivingItem) return;
    const form = new FormData(event.currentTarget);
    const source = String(form.get("expiry_source"));
    setSavingReceive(true);
    try {
      const result = await api<{ batch_id: number; ticks: string }>(
        `/households/${householdId}/grocery-lists/${receivingItem.listId}/items/${receivingItem.item.product_id}/receive`,
        "POST",
        {
          request_key: crypto.randomUUID(),
          product_id: receivingItem.item.product_id,
          quantity: String(form.get("quantity")),
          unit: String(form.get("unit")),
          received: String(form.get("received")),
          expiry: source === "unknown" ? null : String(form.get("expiry")),
          expiry_source: source,
          flagged: false,
        },
      );
      setReceivingItem(null);
      await Promise.all([load(), loadShortages(), onChanged()]);
      notify(`Đã nhập ${receivingItem.name} vào kho · Lô #${result.batch_id}.`);
    } catch (error) { notify(errorText(error, "Không thể nhập mặt hàng vào kho."), true); }
    finally { setSavingReceive(false); }
  };

  const shiftWeek = (direction: number) => {
    const nextStart = addDays(start, direction * 7);
    setStart(nextStart); setEnd(addDays(nextStart, 6));
  };

  if (loading) return <div className="planner-loading"><LoaderCircle className="spin" size={22}/> Đang tải kế hoạch bữa ăn và danh sách mua sắm...</div>;

  return <>
    <section className="page-heading planner-heading"><div><span className="eyebrow">SMARTFOOD AI · LẬP KẾ HOẠCH</span><h1>{view === "meals" ? "Kế hoạch bữa ăn" : "Danh sách mua sắm"}</h1><p>{view === "meals" ? "Sắp xếp bữa ăn trong tuần và theo dõi nhu cầu nguyên liệu của gia đình." : "Tự động đối chiếu thực đơn với kho để xác định những nguyên liệu cần bổ sung."}</p></div><button className="btn btn-outline planner-refresh" onClick={refreshAll} disabled={refreshing}><RefreshCw size={15} className={refreshing ? "spin" : ""}/> Đồng bộ</button></section>

    <div className="planner-tabs"><button className={view === "meals" ? "active" : ""} onClick={() => onNavigate("meals")}><CalendarDays size={16}/> Kế hoạch bữa ăn</button><button className={view === "groceries" ? "active" : ""} onClick={() => onNavigate("groceries")}><ShoppingBasket size={16}/> Danh sách mua sắm</button></div>

    <section className="planner-hero"><div className="planner-hero-copy"><span className="planner-kicker"><CheckCircle2 size={14}/> SMART WEEKLY PLANNER</span><h2>Lên thực đơn chủ động,<br/><em>mua sắm vừa đủ.</em></h2><p>Kế hoạch bữa ăn được kết nối trực tiếp với tồn kho. Nhu cầu mua sắm chỉ tính phần nguyên liệu còn thiếu sau khi đối chiếu thực phẩm có thể sử dụng.</p><div className="planner-hero-meta"><span><CalendarDays size={14}/> {dateLabel(start)} – {dateLabel(end)}</span><span><ShoppingBasket size={14}/> {totalMissingTypes} loại cần bổ sung</span></div></div><div className="planner-hero-art"><div className="planner-plate">🥗</div><span className="planner-food food-one">🥕</span><span className="planner-food food-two">🥑</span><span className="planner-food food-three">🍅</span></div></section>

    <section className="planner-stats"><article className="surface-card planner-stat"><span className="planner-stat-icon"><CalendarDays size={17}/></span><div><small>Bữa ăn trong kỳ</small><b>{mealCount}</b></div></article><article className="surface-card planner-stat"><span className="planner-stat-icon"><Utensils size={17}/></span><div><small>Tổng khẩu phần</small><b>{plannedServings}</b></div></article><article className="surface-card planner-stat"><span className="planner-stat-icon"><ShoppingCart size={17}/></span><div><small>Loại nguyên liệu thiếu</small><b>{totalMissingTypes}</b></div></article><article className="surface-card planner-stat"><span className="planner-stat-icon"><ClipboardList size={17}/></span><div><small>Danh sách đã lưu</small><b>{savedLists.length}</b></div></article></section>

    <section className="surface-card planner-period"><div><span className="eyebrow">KHOẢNG THỜI GIAN</span><h2>Quản lý theo tuần</h2><p>Chọn khoảng ngày để xem lịch và tính nhu cầu mua sắm.</p></div><div className="planner-period-controls"><button className="icon-button" onClick={() => shiftWeek(-1)} aria-label="Tuần trước"><ChevronLeft size={18}/></button><label>Từ ngày<input type="date" value={start} onChange={event => setStart(event.target.value)}/></label><label>Đến ngày<input type="date" min={start} value={end} onChange={event => setEnd(event.target.value)}/></label><button className="icon-button" onClick={() => { const next = mondayOf(today()); setStart(next); setEnd(addDays(next, 6)); }} title="Về tuần hiện tại"><Clock3 size={17}/></button><button className="icon-button" onClick={() => shiftWeek(1)} aria-label="Tuần sau"><ChevronRight size={18}/></button></div></section>

    {view === "meals" ? <section className="planner-main-grid">
      <article className="surface-card planner-calendar-card"><div className="planner-section-head"><div><span className="eyebrow">LỊCH BỮA ĂN</span><h2>Thực đơn của gia đình</h2><p>{mealCount ? `${mealCount} bữa ăn trong khoảng thời gian đã chọn.` : "Chưa có bữa ăn nào trong khoảng thời gian này."}</p></div><button className="btn btn-primary" onClick={openCreateMeal}><Plus size={16}/> Thêm bữa ăn</button></div>
        <div className="planner-search-row"><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Tìm theo tên món ăn..."/><span>{visibleMeals.length} kết quả</span></div>
        <div className="planner-day-list">{Array.from({ length: Math.max(1, Math.min(31, Math.round((new Date(`${end}T12:00:00`).getTime() - new Date(`${start}T12:00:00`).getTime()) / 86400000) + 1)) }, (_, index) => addDays(start, index)).map(day => {
          const dayMeals = visibleMeals.filter(item => item.day === day);
          const date = new Date(`${day}T12:00:00`);
          return <div className="planner-day" key={day}><div className="planner-day-date"><b>{new Intl.DateTimeFormat("vi-VN", { weekday: "short" }).format(date)}</b><strong>{date.getDate()}</strong><small>{new Intl.DateTimeFormat("vi-VN", { month: "short" }).format(date)}</small></div><div className="planner-day-content">{dayMeals.length ? dayMeals.map(meal => {
            const recipe = recipes.find(item => item.id === meal.recipe_id);
            return <div className="planner-meal-item" key={meal.id}><span className="planner-meal-emoji">{recipe?.tags.includes("chay") ? "🥬" : "🍲"}</span><div className="planner-meal-info"><b>{recipe?.name || `Công thức #${meal.recipe_id}`}</b><small>{mealLabel(meal.meal)} · {meal.servings} khẩu phần</small></div><span className="planner-meal-tag">{mealLabel(meal.meal)}</span><button className="icon-button planner-edit" title="Chỉnh sửa bữa ăn" onClick={() => openEditMeal(meal)}><Pencil size={14}/></button><button className="icon-button planner-delete" title="Xóa bữa ăn" disabled={busyItem === `meal-${meal.id}`} onClick={() => deleteMeal(meal)}><Trash2 size={15}/></button></div>;
          }) : <div className="planner-day-empty"><span>Chưa có kế hoạch</span><button onClick={openCreateMeal}><Plus size={13}/> Thêm món</button></div>}</div></div>;
        })}</div>
      </article>
      <aside className="planner-side-column"><article className="surface-card planner-shortage-card"><div className="planner-section-head compact"><div><span className="eyebrow">TỰ ĐỘNG ĐỐI CHIẾU</span><h2>Nguyên liệu còn thiếu</h2></div><ShoppingBasket size={19}/></div><p className="planner-side-description">Nhu cầu được tính từ các bữa ăn đã lên lịch và lượng tồn kho có thể sử dụng.</p>{shortages.length ? <div className="planner-shortage-list">{shortages.slice(0, 6).map(item => <div key={item.product_id}><span><b>{item.name}</b><small>Cần mua thêm</small></span><strong>{formatAmount(item.ticks, item.unit)}</strong></div>)}</div> : <div className="planner-no-shortage"><CheckCircle2 size={22}/><b>Chưa phát hiện thiếu hụt</b><span>Thêm bữa ăn để hệ thống tính nguyên liệu cần mua.</span></div>}<button className="btn btn-outline btn-full" onClick={() => onNavigate("groceries")}>Xem danh sách mua sắm <ChevronRight size={15}/></button></article><article className="planner-tip-card"><span><CheckCircle2 size={16}/></span><div><b>Mẹo lập kế hoạch</b><p>Ưu tiên các món sử dụng thực phẩm sắp hết hạn để giảm lãng phí. Kiểm tra hạn sử dụng thực tế trước khi chế biến.</p></div></article></aside>
    </section> : <section className="planner-grocery-layout">
      <article className="surface-card planner-grocery-card"><div className="planner-section-head"><div><span className="eyebrow">SMART GROCERY LIST</span><h2>Nguyên liệu cần mua</h2><p>Danh sách được tính lại từ thực đơn và tồn kho trong khoảng ngày đã chọn.</p></div><span className="planner-grocery-count">{shortages.length} loại</span></div>
        {shortages.length ? <><div className="planner-grocery-items">{shortages.map(item => <div className="planner-grocery-item" key={item.product_id}><span className="planner-grocery-check"><ShoppingBasket size={16}/></span><span className="planner-grocery-name"><b>{item.name}</b><small>{productMap.get(item.product_id)?.category || "Thực phẩm"}</small></span><strong>{formatAmount(item.ticks, item.unit)}</strong><span className="planner-pending-label">Cần mua</span></div>)}</div><div className="planner-grocery-footer"><span><CheckCircle2 size={15}/> Nhu cầu được đối chiếu lại khi lưu để tránh dùng dữ liệu cũ.</span><button className="btn btn-primary" onClick={createShoppingList} disabled={savingList}>{savingList ? <LoaderCircle className="spin" size={15}/> : <ClipboardList size={15}/>} Lưu danh sách mua</button></div></> : <div className="planner-no-shortage large"><CheckCircle2 size={27}/><b>Không có nguyên liệu cần mua</b><span>Hiện tại kho có đủ nguyên liệu cho các bữa ăn trong khoảng ngày đã chọn, hoặc chưa có bữa ăn nào được lên lịch.</span><button className="btn btn-outline" onClick={() => onNavigate("meals")}>Mở kế hoạch bữa ăn</button></div>}
      </article>
      <aside className="surface-card planner-saved-card"><div className="planner-section-head compact"><div><span className="eyebrow">ĐÃ LƯU</span><h2>Danh sách mua sắm</h2></div><ShoppingCart size={19}/></div>{savedLists.length ? <div className="planner-saved-list">{savedLists.map(list => {
        const purchased = list.items.filter(item => Boolean(item.purchased)).length;
        const percent = list.items.length ? Math.round(purchased / list.items.length * 100) : 0;
        return <div className="planner-saved-group" key={list.id}><div className="planner-saved-head"><div><b>Danh sách #{list.id}</b><small>{dateLabel(list.start)} – {dateLabel(list.end)}</small></div><strong>{percent}%</strong></div><div className="planner-saved-progress"><i style={{ width: `${percent}%` }}/></div><div className="planner-saved-items">{list.items.map(item => {
          const product = productMap.get(item.product_id);
          const unit = product?.base_unit || "g";
          return <div className={`planner-saved-item ${item.purchased ? "purchased" : ""}`} key={item.product_id}><label className="planner-saved-item-main"><input type="checkbox" checked={Boolean(item.purchased)} disabled={Boolean(item.received_batch_id) || busyItem === `${list.id}-${item.product_id}`} onChange={event => togglePurchased(list.id, item.product_id, event.target.checked)}/><span><b>{product?.name || `Thực phẩm #${item.product_id}`}</b><small>{formatAmount(item.ticks, unit)}</small></span></label>{item.received_batch_id ? <span className="planner-received-label"><CheckCircle2 size={13}/> Đã nhập · Lô #{item.received_batch_id}</span> : item.purchased ? <button className="planner-receive-button" disabled={savingReceive} onClick={() => openReceive(list.id, item)}><PackageCheck size={13}/> Nhập kho</button> : <span className="planner-pending-label">Chưa mua</span>}</div>;
        })}</div></div>;
      })}</div> : <div className="planner-saved-empty"><ClipboardList size={25}/><b>Chưa có danh sách đã lưu</b><span>Tạo danh sách từ nguyên liệu còn thiếu để theo dõi quá trình mua sắm.</span></div>}</aside>
    </section>}

    {modalOpen && <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) { setModalOpen(false); setEditingMeal(null); } }}><section className="inventory-modal planner-modal" role="dialog" aria-modal="true" aria-labelledby="planner-modal-title"><div className="modal-heading"><div><span className="eyebrow">THÊM VÀO THỰC ĐƠN</span><h2 id="planner-modal-title">{editingMeal ? "Chỉnh sửa bữa ăn" : "Lên kế hoạch bữa ăn"}</h2><p>Chọn công thức trong danh mục đã được kiểm duyệt.</p></div><button className="icon-button" onClick={() => { setModalOpen(false); setEditingMeal(null); }} aria-label="Đóng"><X size={18}/></button></div><form className="inventory-form" onSubmit={createMeal}><label>Món ăn<select name="recipe_id" required defaultValue={editingMeal?.recipe_id ?? ""}><option value="" disabled>Chọn công thức</option>{recipes.map(recipe => <option key={recipe.id} value={recipe.id}>{recipe.name}</option>)}</select></label><div className="planner-form-row"><label>Ngày thực hiện<input type="date" name="day" min={today()} defaultValue={editingMeal?.day ?? (start >= today() ? start : today())} required/></label><label>Bữa ăn<select name="meal" defaultValue={editingMeal?.meal ?? "trưa"}><option value="sáng">Bữa sáng</option><option value="trưa">Bữa trưa</option><option value="tối">Bữa tối</option><option value="phụ">Bữa phụ</option></select></label></div><label>Số khẩu phần<input type="number" name="servings" min="1" max="100" defaultValue={editingMeal?.servings ?? 2} required/></label><div className="planner-modal-note"><CheckCircle2 size={15}/> Nguyên liệu còn thiếu sẽ tự động được tính vào nhu cầu mua sắm.</div><div className="modal-actions"><button type="button" className="btn btn-outline" onClick={() => { setModalOpen(false); setEditingMeal(null); }}>Hủy</button><button className="btn btn-primary" disabled={savingMeal}>{savingMeal ? "Đang lưu..." : editingMeal ? "Cập nhật bữa ăn" : "Lưu bữa ăn"}<CalendarPlus size={15}/></button></div></form></section></div>}
    {receivingItem && <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget && !savingReceive) setReceivingItem(null); }}><section className="inventory-modal planner-modal" role="dialog" aria-modal="true" aria-labelledby="receive-grocery-title"><div className="modal-heading"><div><span className="eyebrow">SMART INVENTORY SYNC</span><h2 id="receive-grocery-title">Nhập thực phẩm vào kho</h2><p>{receivingItem.name} · Danh sách #{receivingItem.listId}</p></div><button className="icon-button" onClick={() => setReceivingItem(null)} disabled={savingReceive} aria-label="Đóng"><X size={18}/></button></div><form className="inventory-form" onSubmit={confirmReceive}><div className="planner-form-row"><label>Số lượng thực nhận<input type="number" name="quantity" min="0.001" step="0.001" defaultValue={receivingItem.unit === "quả" ? receivingItem.item.ticks : String(Number(receivingItem.item.ticks) / 1000)} required/></label><label>Đơn vị<select name="unit" defaultValue={receivingItem.unit}><option value="g">g</option><option value="kg">kg</option><option value="ml">ml</option><option value="l">lít</option><option value="quả">quả</option></select></label></div><label>Ngày nhận hàng<input type="date" name="received" defaultValue={today()} max={today()} required/></label><div className="planner-form-row"><label>Nguồn hạn sử dụng<select name="expiry_source" defaultValue="label"><option value="label">Trên nhãn sản phẩm</option><option value="user">Người dùng xác nhận</option><option value="estimate">Ước tính – cần kiểm tra</option><option value="unknown">Chưa xác định</option></select></label><label>Hạn sử dụng<input type="date" name="expiry" defaultValue={addDays(today(), 7)}/></label></div><div className="planner-modal-note"><ShieldCheck size={15}/> Xác nhận sẽ tạo một lô hàng mới và ghi sổ nhập kho. Hệ thống chống nhập trùng cho cùng một mặt hàng trong danh sách này.</div><div className="modal-actions"><button type="button" className="btn btn-outline" onClick={() => setReceivingItem(null)} disabled={savingReceive}>Hủy</button><button className="btn btn-primary" disabled={savingReceive}>{savingReceive ? <LoaderCircle className="spin" size={15}/> : <PackageCheck size={15}/>} Xác nhận nhập kho</button></div></form></section></div>}
  </>;
}
