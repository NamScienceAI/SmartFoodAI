"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import ReceiptPage from "@/components/receipt-page";
import RecipePage from "@/components/recipe-page";
import MealPlannerPage from "@/components/meal-planner-page";
import {
  Alert, ApiError, Batch, CatalogLookup, CatalogProduct, Household, SessionSnapshot, User, alertLabel, api,
  batchState, dateLabel, daysUntil, setActor,
} from "@/lib/api";
import {
  Bell, CalendarDays, Carrot, ChefHat, ChevronDown, ChevronRight,
  CircleHelp, Clock3, Command, CookingPot, FileImage, Home,
  Leaf, LogOut, Menu, Package, Search, Settings2, ShieldCheck,
  ShoppingBasket, Sparkles, Sprout, TrendingDown, Users,
  X, AlertTriangle, CheckCircle2, RefreshCw, ArrowUpRight, Plus, Pencil, Minus,
} from "lucide-react";

type Screen = "loading" | "auth" | "onboard" | "app";
type Page = "dashboard" | "inventory" | "alerts" | "recipes" | "receipts" | "meals" | "groceries" | "reports" | "household";

const pageLabels: Record<Page, string> = {
  dashboard: "Tổng quan", inventory: "Kho thực phẩm", alerts: "Thông báo hạn sử dụng",
  recipes: "Gợi ý món ăn", receipts: "Quét hóa đơn", meals: "Kế hoạch bữa ăn",
  groceries: "Danh sách mua sắm", reports: "Thống kê lãng phí", household: "Hộ gia đình",
};

const navGroups = [
  { title: "KHÔNG GIAN", items: [{ id: "dashboard", label: "Tổng quan", icon: Home }, { id: "inventory", label: "Kho thực phẩm", icon: Package }, { id: "receipts", label: "Quét hóa đơn", icon: FileImage }] },
  { title: "TRỢ LÝ THÔNG MINH", items: [{ id: "recipes", label: "Gợi ý món ăn", icon: Sparkles, tag: "AI" }, { id: "meals", label: "Kế hoạch bữa ăn", icon: CalendarDays }, { id: "groceries", label: "Danh sách mua sắm", icon: ShoppingBasket }] },
  { title: "PHÂN TÍCH", items: [{ id: "alerts", label: "Cảnh báo hạn dùng", icon: Bell }, { id: "reports", label: "Thống kê lãng phí", icon: TrendingDown }] },
];

function initials(name: string) { return name.trim().slice(0, 1).toUpperCase() || "S"; }
function formatNumber(value: number) { return new Intl.NumberFormat("vi-VN").format(value); }
function friendlyDate() { return new Intl.DateTimeFormat("vi-VN", { weekday: "long", day: "2-digit", month: "long", year: "numeric" }).format(new Date()); }

export default function SmartFoodApp() {
  const [screen, setScreen] = useState<Screen>("loading");
  const [user, setUser] = useState<User | null>(null);
  const [household, setHousehold] = useState<Household | null>(null);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [page, setPage] = useState<Page>("dashboard");
  const [registering, setRegistering] = useState(false);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ message: string; error?: boolean } | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [inventoryFilter, setInventoryFilter] = useState("all");
  const [inventoryModal, setInventoryModal] = useState<"receive" | "movement" | "review" | null>(null);
  const [selectedBatch, setSelectedBatch] = useState<Batch | null>(null);

  const notify = useCallback((message: string, error = false) => {
    setToast({ message, error });
    window.setTimeout(() => setToast(null), 3400);
  }, []);

  const loadWorkspace = useCallback(async (snapshot?: SessionSnapshot) => {
    const current = snapshot ?? await api<SessionSnapshot>("/households/current");
    setUser(current.user);
    setActor(current.user.id);
    setHousehold(current.household);
    if (!current.household) { setScreen("onboard"); return; }
    const [inventory, inbox] = await Promise.all([
      api<Batch[]>(`/households/${current.household.id}/inventory/batches`),
      api<Alert[]>(`/households/${current.household.id}/alerts`),
    ]);
    setBatches(inventory);
    setAlerts(inbox);
    setScreen("app");
  }, []);

  useEffect(() => {
    let active = true;
    api<SessionSnapshot>("/households/current")
      .then(async snapshot => { if (active) await loadWorkspace(snapshot); })
      .catch(error => {
        if (!active) return;
        setActor(null);
        setScreen("auth");
        if (!(error instanceof ApiError && error.status === 401)) notify(error.message || "Không thể tải dữ liệu.", true);
      });
    return () => { active = false; };
  }, [loadWorkspace, notify]);

  const refresh = async () => {
    if (!household) return;
    setBusy(true);
    try { await loadWorkspace(); notify("Dữ liệu đã được cập nhật."); }
    catch (error) { notify(error instanceof Error ? error.message : "Không thể làm mới dữ liệu.", true); }
    finally { setBusy(false); }
  };

  const handleAuth = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const payload = { username: String(form.get("username") || ""), password: String(form.get("password") || "") };
    setBusy(true);
    try {
      if (registering) {
        await api("/auth/register", "POST", payload);
        setRegistering(false);
        notify("Tạo tài khoản thành công. Hãy đăng nhập.");
        event.currentTarget.reset();
      } else {
        await api("/auth/login", "POST", payload);
        await loadWorkspace();
      }
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể xác thực.", true); }
    finally { setBusy(false); }
  };

  const handleHousehold = async (event: FormEvent<HTMLFormElement>, joining: boolean) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setBusy(true);
    try {
      await api(joining ? "/households/join" : "/households", "POST", joining ? { code: form.get("code") } : { name: form.get("name") });
      await loadWorkspace();
      notify(joining ? "Bạn đã tham gia hộ gia đình." : "Đã tạo hộ gia đình mới.");
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể thiết lập hộ gia đình.", true); }
    finally { setBusy(false); }
  };

  const logout = async () => {
    try { await api("/auth/logout", "POST"); } catch { /* clear local state regardless */ }
    setActor(null); setUser(null); setHousehold(null); setBatches([]); setAlerts([]); setScreen("auth"); setRegistering(false); setPage("dashboard");
  };

  const inventorySaved = async (message: string) => {
    setInventoryModal(null); setSelectedBatch(null);
    await loadWorkspace(); notify(message);
  };

  const markRead = async (alert: Alert) => {
    if (!household) return;
    try {
      await api(`/households/${household.id}/alerts/${alert.batch_id}/${encodeURIComponent(alert.reason)}/read`, "PUT");
      setAlerts(current => current.map(item => item.batch_id === alert.batch_id && item.reason === alert.reason ? { ...item, read: true } : item));
      notify("Đã đánh dấu thông báo là đã đọc.");
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể cập nhật thông báo.", true); }
  };

  const unread = alerts.filter(item => !item.read).length;
  const visibleBatches = useMemo(() => batches.filter(batch => {
    const match = batch.name.toLocaleLowerCase("vi").includes(query.trim().toLocaleLowerCase("vi"));
    const state = batchState(batch);
    const statusMatch = inventoryFilter === "all" || (inventoryFilter === "due" && state.tone === "warning") || (inventoryFilter === "expired" && state.tone === "danger") || (inventoryFilter === "unknown" && (batch.expiry_source === "unknown" || batch.expiry_source === "estimate"));
    return match && statusMatch;
  }), [batches, query, inventoryFilter]);

  if (screen === "loading") return <div className="loading-screen"><div className="brand-mark"><Sprout size={25} /></div><span>Đang chuẩn bị không gian SmartFood...</span><div className="loading-bar" /></div>;

  if (screen === "auth") return <>
    <main className="auth-layout">
      <section className="auth-panel">
        <a className="brand" href="/"><span className="brand-mark"><Sprout size={23} /></span><span>smartfood<span className="brand-ai">.ai</span></span></a>
        <div className="auth-content">
          <span className="eyebrow">QUẢN LÝ THỰC PHẨM THÔNG MINH</span>
          <h1>{registering ? "Bắt đầu hành trình sống xanh." : "Chào mừng bạn trở lại."}</h1>
          <p className="muted">Một không gian gọn gàng để quản lý thực phẩm, chăm sóc bữa ăn và giảm lãng phí cho gia đình.</p>
          <form className="form-stack" onSubmit={handleAuth}>
            <label>Tên đăng nhập<input name="username" minLength={3} maxLength={40} autoComplete="username" placeholder="Ví dụ: nhatnam" required /></label>
            <label>Mật khẩu<input name="password" type="password" minLength={8} maxLength={128} autoComplete={registering ? "new-password" : "current-password"} placeholder="Tối thiểu 8 ký tự" required /></label>
            <button className="btn btn-primary btn-full" disabled={busy}>{busy ? "Đang xử lý..." : registering ? "Tạo tài khoản" : "Đăng nhập"}<ChevronRight size={17} /></button>
          </form>
          <button className="text-button auth-switch" onClick={() => setRegistering(value => !value)}>{registering ? "Đã có tài khoản? Đăng nhập" : "Chưa có tài khoản? Tạo tài khoản"}</button>
          <div className="auth-security"><ShieldCheck size={16} /> Phiên đăng nhập được bảo vệ bằng cookie HttpOnly.</div>
        </div>
        <span className="auth-copyright">© 2026 SmartFood AI · Ăn tươi, sống xanh.</span>
      </section>
      <aside className="auth-visual">
        <div className="visual-orb orb-one" /><div className="visual-orb orb-two" />
        <div className="visual-copy"><span className="visual-kicker"><Sparkles size={15} /> SMARTER FOOD, BETTER LIVING</span><h2>Chăm sóc căn bếp.<br /><em>Nuôi dưỡng tương lai.</em></h2><p>Biến những nguyên liệu sẵn có thành lựa chọn thông minh hơn mỗi ngày.</p>
          <div className="visual-feature"><span><Leaf size={18} /></span><div><b>Ăn ngon, ít lãng phí</b><small>Ưu tiên thực phẩm cần sử dụng trước.</small></div></div>
          <div className="visual-feature"><span><CookingPot size={18} /></span><div><b>Khơi nguồn cảm hứng</b><small>Gợi ý bữa ăn dựa trên nguyên liệu của bạn.</small></div></div>
        </div>
        <div className="floating-food food-a">🥑</div><div className="floating-food food-b">🥬</div><div className="floating-food food-c">🍋</div>
        <div className="visual-footer">TỪ CĂN BẾP NHỎ ĐẾN MỘT HÀNH TINH XANH HƠN</div>
      </aside>
    </main>
    {toast && <Toast {...toast} />}
  </>;

  if (screen === "onboard") return <>
    <main className="onboard-screen">
      <a className="brand" href="/"><span className="brand-mark"><Sprout size={23} /></span><span>smartfood<span className="brand-ai">.ai</span></span></a>
      <div className="onboard-intro"><span className="eyebrow">CHỈ CÒN MỘT BƯỚC</span><h1>Tạo không gian cho gia đình bạn.</h1><p className="muted">Tạo một hộ mới hoặc tham gia bằng mã mời từ thành viên khác.</p></div>
      <div className="onboard-cards">
        <form className="onboard-card" onSubmit={event => handleHousehold(event, false)}><div className="onboard-icon"><Home size={22} /></div><h2>Tạo hộ gia đình</h2><p>Thiết lập không gian riêng để cùng quản lý thực phẩm và bữa ăn.</p><label>Tên hộ gia đình<input name="name" maxLength={100} placeholder="Ví dụ: Gia đình Nguyễn" required /></label><button className="btn btn-primary btn-full" disabled={busy}>Tạo hộ gia đình <ArrowUpRight size={16} /></button></form>
        <form className="onboard-card" onSubmit={event => handleHousehold(event, true)}><div className="onboard-icon soft"><Users size={22} /></div><h2>Tham gia hộ có sẵn</h2><p>Nhập mã mời được chia sẻ bởi chủ hộ để kết nối với gia đình.</p><label>Mã mời<input name="code" maxLength={128} placeholder="Dán mã mời tại đây" required /></label><button className="btn btn-outline btn-full" disabled={busy}>Tham gia hộ <ChevronRight size={16} /></button></form>
      </div>
      <button className="text-button" onClick={logout}><LogOut size={15} /> Đăng xuất</button>
    </main>
    {toast && <Toast {...toast} />}
  </>;

  return <div className="app-shell">
    {mobileOpen && <button className="mobile-scrim" aria-label="Đóng menu" onClick={() => setMobileOpen(false)} />}
    <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
      <div className="sidebar-brand-row"><a className="brand" href="/"><span className="brand-mark"><Sprout size={22} /></span><span>smartfood<span className="brand-ai">.ai</span></span></a><button className="icon-button sidebar-close" onClick={() => setMobileOpen(false)} aria-label="Đóng menu"><X size={18} /></button></div>
      <div className="household-switcher"><div className="household-avatar"><Home size={17} /></div><div className="household-info"><b>{household?.name || "Gia đình của bạn"}</b><small>Không gian gia đình</small></div><ChevronDown size={15} className="muted-icon" /></div>
      <nav className="sidebar-nav" aria-label="Điều hướng chính">
        {navGroups.map(group => <div className="nav-group" key={group.title}><span className="nav-group-title">{group.title}</span>{group.items.map(item => {
          const Icon = item.icon; const active = page === item.id;
          return <button key={item.id} className={`nav-item ${active ? "active" : ""}`} onClick={() => { setPage(item.id as Page); setMobileOpen(false); }}><Icon size={18} strokeWidth={1.8} /><span>{item.label}</span>{"tag" in item && <span className="nav-tag">AI</span>}{item.id === "alerts" && unread > 0 && <span className="nav-count">{unread}</span>}</button>;
        })}</div>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-tip"><div className="tip-icon"><Leaf size={17} /></div><b>Mẹo sống xanh</b><p>Kiểm tra thực phẩm sắp hết hạn để ưu tiên sử dụng trong bữa ăn tiếp theo.</p><button onClick={() => setPage("inventory")}>Xem kho thực phẩm <ArrowUpRight size={13} /></button></div>
        <button className="nav-item" onClick={() => setPage("household")}><Users size={18} /><span>Hộ gia đình</span></button>
        <button className="nav-item" onClick={() => notify("Cấu hình tài khoản sẽ được hoàn thiện ở giai đoạn tiếp theo.")}><Settings2 size={18} /><span>Cài đặt</span></button>
        <div className="sidebar-user"><div className="user-avatar">{initials(user?.username || "S")}</div><div className="user-meta"><b>{user?.username}</b><small>Thành viên gia đình</small></div><button className="icon-button logout-button" title="Đăng xuất" onClick={logout}><LogOut size={17} /></button></div>
      </div>
    </aside>

    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="icon-button mobile-menu-button" onClick={() => setMobileOpen(true)} aria-label="Mở menu"><Menu size={20} /></button><div className="breadcrumb"><span>Không gian gia đình</span><ChevronRight size={14} /><b>{pageLabels[page]}</b></div></div><div className="topbar-actions"><div className="topbar-date"><CalendarDays size={15} /> {friendlyDate()}</div><button className="icon-button notification-button" onClick={() => setPage("alerts")} aria-label="Thông báo"><Bell size={18} />{unread > 0 && <i />}</button><div className="topbar-divider" /><button className="topbar-profile" onClick={() => notify(`Bạn đang đăng nhập với tài khoản ${user?.username}.`)}><span className="user-avatar small">{initials(user?.username || "S")}</span><span>{user?.username}</span><ChevronDown size={14} /></button></div></header>
      <div className="content-wrap">
        {page === "dashboard" && <Dashboard user={user} household={household} batches={batches} alerts={alerts} onNavigate={setPage} onRefresh={refresh} busy={busy} />}
        {page === "inventory" && <InventoryPage batches={visibleBatches} query={query} setQuery={setQuery} filter={inventoryFilter} setFilter={setInventoryFilter} onAdd={() => setInventoryModal("receive")} onMovement={batch => { setSelectedBatch(batch); setInventoryModal("movement"); }} onReview={batch => { setSelectedBatch(batch); setInventoryModal("review"); }} />}
        {page === "alerts" && <AlertsPage alerts={alerts} onMarkRead={markRead} />}
        {page === "receipts" && household && <ReceiptPage householdId={household.id} onImported={async () => { await loadWorkspace(); }} notify={notify} />}
        {page === "recipes" && household && user && <RecipePage householdId={household.id} userId={user.id} batches={batches} notify={notify} onPlanSaved={async () => { await loadWorkspace(); }} />}
        {(page === "meals" || page === "groceries") && household && user && <MealPlannerPage householdId={household.id} userId={user.id} view={page} onNavigate={setPage} notify={notify} onChanged={async () => { await loadWorkspace(); }} />}
        {!(["dashboard", "inventory", "alerts", "receipts", "recipes", "meals", "groceries"] as Page[]).includes(page) && <ComingSoon page={page} onBack={() => setPage("dashboard")} />}
      </div>
      {inventoryModal === "receive" && household && <InventoryModal mode="receive" householdId={household.id} onClose={() => setInventoryModal(null)} onSaved={inventorySaved} notify={notify} />}
      {inventoryModal === "movement" && household && selectedBatch && <InventoryModal mode="movement" householdId={household.id} batch={selectedBatch} onClose={() => { setInventoryModal(null); setSelectedBatch(null); }} onSaved={inventorySaved} notify={notify} />}
      {inventoryModal === "review" && household && selectedBatch && <InventoryModal mode="review" householdId={household.id} batch={selectedBatch} onClose={() => { setInventoryModal(null); setSelectedBatch(null); }} onSaved={inventorySaved} notify={notify} />}
      <footer className="app-footer"><span>© 2026 SmartFood AI</span><span><span className="online-dot" /> Hệ thống đang hoạt động</span><button onClick={() => notify("SmartFood AI · Phiên bản giao diện Next.js.")}><CircleHelp size={14} /> Trợ giúp</button></footer>
    </main>
    {toast && <Toast {...toast} />}
  </div>;
}

function Dashboard({ user, household, batches, alerts, onNavigate, onRefresh, busy }: {
  user: User | null; household: Household | null; batches: Batch[]; alerts: Alert[];
  onNavigate: (page: Page) => void; onRefresh: () => void; busy: boolean;
}) {
  const activeBatches = batches.filter(batch => Number(batch.ticks) > 0);
  const urgent = alerts.filter(alert => ["due_soon", "past_date"].includes(alert.reason));
  const expiring = activeBatches.filter(batch => ["label", "user"].includes(batch.expiry_source)).filter(batch => { const days = daysUntil(batch.expiry); return days !== null && days >= 0 && days <= 7; });
  const unread = alerts.filter(alert => !alert.read).length;
  const categories = [
    { label: "Còn hạn", count: activeBatches.filter(batch => batchState(batch).tone === "success").length, color: "#4F9B70" },
    { label: "Sắp hết hạn", count: activeBatches.filter(batch => ["label", "user"].includes(batch.expiry_source) && batchState(batch).tone === "warning").length, color: "#E7A34B" },
    { label: "Quá hạn", count: activeBatches.filter(batch => batchState(batch).tone === "danger").length, color: "#D66A5E" },
    { label: "Cần xác minh", count: activeBatches.filter(batch => ["unknown", "estimate"].includes(batch.expiry_source)).length, color: "#A5B1A8" },
  ];
  const total = Math.max(activeBatches.length, 1);
  const newest = [...activeBatches].sort((a, b) => b.received.localeCompare(a.received)).slice(0, 5);
  const focusAlerts = [...alerts].sort((a, b) => Number(a.read) - Number(b.read)).slice(0, 4);

  return <>
    <section className="welcome-row"><div><span className="eyebrow">KHÔNG GIAN GIA ĐÌNH</span><h1>Chào buổi tối, {user?.username || "bạn"} <span className="wave">✦</span></h1><p>Một căn bếp ngăn nắp bắt đầu từ những lựa chọn nhỏ mỗi ngày.</p></div><button className="btn btn-outline refresh-btn" onClick={onRefresh} disabled={busy}><RefreshCw size={16} className={busy ? "spin" : ""} /> Làm mới dữ liệu</button></section>
    <section className="hero-banner"><div className="hero-pattern" /><div className="hero-copy"><span className="hero-label"><Sparkles size={14} /> SMARTFOOD INSIGHT</span><h2>Ăn ngon hơn. Sống xanh hơn.</h2><p>{household?.name || "Gia đình bạn"} đang có <b>{activeBatches.length} lô thực phẩm</b> trong kho. Hãy ưu tiên sử dụng những nguyên liệu cần chú ý để giảm lãng phí.</p><button onClick={() => onNavigate("inventory")}>Khám phá kho thực phẩm <ArrowUpRight size={15} /></button></div><div className="hero-illustration"><div className="hero-leaf leaf-one">🥬</div><div className="hero-leaf leaf-two">🥑</div><div className="hero-leaf leaf-three">🍋</div><div className="hero-orbit" /></div><div className="hero-household"><Users size={14} /> {household?.members?.length || 1} thành viên</div></section>

    <section className="metrics-grid">
      <MetricCard icon={<Package size={19} />} label="Thực phẩm trong kho" value={formatNumber(activeBatches.length)} note="Số lô đang còn tồn" tone="green" />
      <MetricCard icon={<AlertTriangle size={19} />} label="Cần chú ý" value={formatNumber(urgent.length)} note="Quá hạn hoặc còn tối đa 3 ngày" tone="amber" />
      <MetricCard icon={<Clock3 size={19} />} label="Sắp đến hạn · 7 ngày" value={formatNumber(expiring.length)} note="Theo hạn nhãn hoặc người dùng" tone="blue" />
      <MetricCard icon={<Bell size={19} />} label="Thông báo chưa đọc" value={formatNumber(unread)} note="Trạng thái riêng của tài khoản" tone="rose" />
    </section>

    <section className="dashboard-columns">
      <article className="surface-card attention-card"><div className="section-heading"><div><span className="eyebrow">ĐỪNG BỎ LỠ</span><h2>Thực phẩm cần chú ý</h2><p>Ưu tiên kiểm tra các lô có cảnh báo.</p></div><button className="inline-link" onClick={() => onNavigate("alerts")}>Tất cả cảnh báo <ArrowUpRight size={14} /></button></div>
        {focusAlerts.length ? <div className="attention-list">{focusAlerts.map((alert, index) => <div className="attention-item" key={`${alert.batch_id}-${alert.reason}`}><div className={`attention-icon ${alert.reason === "past_date" ? "danger" : alert.reason === "verify_expiry" || alert.reason === "flagged" ? "muted" : "warning"}`}>{alert.reason === "past_date" ? <AlertTriangle size={17} /> : <Clock3 size={17} />}</div><div className="attention-copy"><b>{alert.product}</b><span>{alert.expiry ? `Hạn sử dụng: ${dateLabel(alert.expiry)}` : "Chưa có ngày hạn xác nhận"}</span></div><span className={`attention-status ${alert.reason === "past_date" ? "danger-text" : "warning-text"}`}>{alertLabel(alert)}</span></div>)}</div> : <div className="empty-inline"><span><CheckCircle2 size={20} /></span><div><b>Không có cảnh báo cần xử lý</b><small>Kho thực phẩm của bạn chưa có mục nào cần chú ý.</small></div></div>}
      </article>
      <article className="surface-card stock-card"><div className="section-heading"><div><span className="eyebrow">TÌNH TRẠNG KHO</span><h2>Tổng quan tồn kho</h2><p>Phân loại theo trạng thái hạn sử dụng.</p></div><span className="chart-total">{activeBatches.length} <small>lô</small></span></div>
        <div className="stock-chart"><div className="donut" style={{ background: activeBatches.length ? `conic-gradient(${categories.map((item, index) => { const before = categories.slice(0, index).reduce((sum, part) => sum + part.count, 0); const start = before / total * 100; const end = (before + item.count) / total * 100; return `${item.color} ${start}% ${end}%`; }).join(", ")})` : "#e9eee8" }}><div className="donut-center"><b>{activeBatches.length}</b><span>Tổng lô</span></div></div><div className="stock-legend">{categories.map(item => <div className="legend-row" key={item.label}><i style={{ background: item.color }} /><span>{item.label}</span><b>{item.count}</b></div>)}</div></div>
        <div className="stock-footnote"><Leaf size={14} /> Hạn ước tính và chưa xác định không được tính là hạn đã xác nhận.</div>
      </article>
    </section>

    <section className="dashboard-bottom">
      <article className="surface-card recent-card"><div className="section-heading"><div><span className="eyebrow">CẬP NHẬT MỚI</span><h2>Tồn kho gần đây</h2><p>Các lô thực phẩm mới được ghi nhận.</p></div><button className="inline-link" onClick={() => onNavigate("inventory")}>Mở kho <ArrowUpRight size={14} /></button></div>
        {newest.length ? <div className="recent-table-wrap"><table className="recent-table"><thead><tr><th>TÊN THỰC PHẨM</th><th>SỐ LƯỢNG · BƯỚC LƯU</th><th>HẠN SỬ DỤNG</th><th>TRẠNG THÁI</th></tr></thead><tbody>{newest.map(batch => { const status = batchState(batch); return <tr key={batch.id}><td><div className="table-product"><span className="product-emoji">{foodEmoji(batch.name)}</span><span><b>{batch.name}</b><small>Lô #{batch.id}</small></span></div></td><td>{batch.ticks} <span className="unit-label">{batch.base_unit}</span></td><td>{dateLabel(batch.expiry)}</td><td><StatusPill tone={status.tone}>{status.label}</StatusPill></td></tr>; })}</tbody></table></div> : <EmptyState title="Kho thực phẩm chưa có dữ liệu" description="Hãy bắt đầu nhập thực phẩm để theo dõi tồn kho tại đây." action="Xem hướng dẫn" onAction={() => onNavigate("inventory")} />}
      </article>
      <article className="surface-card quick-card"><div className="section-heading"><div><span className="eyebrow">BẮT ĐẦU NHANH</span><h2>Thao tác nhanh</h2><p>Truy cập những chức năng thường dùng.</p></div></div><div className="quick-actions"><QuickAction icon={<Package size={18} />} title="Kho thực phẩm" description="Xem và quản lý các lô hàng" onClick={() => onNavigate("inventory")} /><QuickAction icon={<FileImage size={18} />} title="Quét hóa đơn" description="Nhập thực phẩm từ hóa đơn" onClick={() => onNavigate("receipts")} /><QuickAction icon={<Bell size={18} />} title="Thông báo hạn" description={`${unread} thông báo chưa đọc`} onClick={() => onNavigate("alerts")} /><QuickAction icon={<ChefHat size={18} />} title="Gợi ý món ăn AI" description="Tận dụng nguyên liệu sẵn có" onClick={() => onNavigate("recipes")} /></div></article>
    </section>
  </>;
}

function MetricCard({ icon, label, value, note, tone }: { icon: ReactNode; label: string; value: string; note: string; tone: string }) {
  return <article className="metric-card"><div className={`metric-icon ${tone}`}>{icon}</div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-note">{note}</div></article>;
}
function QuickAction({ icon, title, description, onClick }: { icon: ReactNode; title: string; description: string; onClick: () => void }) {
  return <button className="quick-action" onClick={onClick}><span className="quick-icon">{icon}</span><span className="quick-copy"><b>{title}</b><small>{description}</small></span><ChevronRight size={16} /></button>;
}
function StatusPill({ tone, children }: { tone: string; children: ReactNode }) { return <span className={`status-pill ${tone}`}>{children}</span>; }
function EmptyState({ title, description, action, onAction }: { title: string; description: string; action: string; onAction: () => void }) {
  return <div className="empty-state"><div className="empty-illustration"><Carrot size={28} /></div><b>{title}</b><p>{description}</p><button className="btn btn-outline" onClick={onAction}>{action}</button></div>;
}
function foodEmoji(name: string) {
  const value = name.toLocaleLowerCase("vi");
  if (/rau|cải|xà lách|bắp cải|bông cải/.test(value)) return "🥬";
  if (/thịt|bò|heo|gà/.test(value)) return "🥩";
  if (/cá|tôm|mực/.test(value)) return "🐟";
  if (/sữa|phô mai|yaourt/.test(value)) return "🥛";
  if (/trứng/.test(value)) return "🥚";
  if (/cam|chanh|quýt/.test(value)) return "🍊";
  if (/chuối/.test(value)) return "🍌";
  if (/táo/.test(value)) return "🍎";
  return "🥑";
}

function InventoryPage({ batches, query, setQuery, filter, setFilter, onAdd, onMovement, onReview }: { batches: Batch[]; query: string; setQuery: (value: string) => void; filter: string; setFilter: (value: string) => void; onAdd: () => void; onMovement: (batch: Batch) => void; onReview: (batch: Batch) => void }) {
  return <><PageHeader eyebrow="QUẢN LÝ NGUYÊN LIỆU" title="Kho thực phẩm" description="Theo dõi các lô thực phẩm, số lượng và thông tin hạn sử dụng." /><div className="inventory-heading-actions"><div className="info-banner"><ShieldCheck size={17} /><span>Số lượng hiển thị theo bước lưu cơ sở của Backend. Hạn ước tính hoặc chưa xác định không được xem là hạn đã xác nhận.</span></div><button className="btn btn-primary" onClick={onAdd}><Plus size={16} /> Nhập thực phẩm</button></div><div className="table-toolbar"><div className="search-field"><Search size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Tìm theo tên thực phẩm..." /></div><select value={filter} onChange={event => setFilter(event.target.value)}><option value="all">Tất cả trạng thái</option><option value="due">Sắp hết hạn</option><option value="expired">Quá hạn</option><option value="unknown">Chưa xác định / cần kiểm tra</option></select><span className="result-count">{batches.length} lô thực phẩm</span></div><section className="surface-card inventory-page-card">{batches.length ? <div className="recent-table-wrap"><table className="recent-table"><thead><tr><th>THỰC PHẨM</th><th>SỐ LƯỢNG · BƯỚC LƯU</th><th>NGÀY NHẬN</th><th>HẠN SỬ DỤNG</th><th>TRẠNG THÁI</th><th>THAO TÁC</th></tr></thead><tbody>{batches.map(batch => { const status = batchState(batch); return <tr key={batch.id}><td><div className="table-product"><span className="product-emoji">{foodEmoji(batch.name)}</span><span><b>{batch.name}</b><small>Lô #{batch.id} · {batch.base_unit}</small></span></div></td><td>{batch.ticks}</td><td>{dateLabel(batch.received)}</td><td>{dateLabel(batch.expiry)}</td><td><StatusPill tone={status.tone}>{status.label}</StatusPill></td><td><div className="inventory-row-actions"><button className="icon-button" title="Ghi nhận sử dụng / bỏ đi / kiểm kê" onClick={() => onMovement(batch)}><Minus size={15} /></button><button className="icon-button" title="Cập nhật hạn sử dụng" onClick={() => onReview(batch)}><Pencil size={15} /></button></div></td></tr>; })}</tbody></table></div> : <EmptyState title="Chưa có thực phẩm phù hợp" description="Hãy nhập thực phẩm đầu tiên hoặc thay đổi bộ lọc để xem kết quả." action="Xóa bộ lọc" onAction={() => { setQuery(""); setFilter("all"); }} />}</section></>;
}

function InventoryModal({ mode, householdId, batch, onClose, onSaved, notify }: { mode: "receive" | "movement" | "review"; householdId: number; batch?: Batch; onClose: () => void; onSaved: (message: string) => void; notify: (message: string, error?: boolean) => void }) {
  const [busy, setBusy] = useState(false); const [productQuery, setProductQuery] = useState("");
  const [lookup, setLookup] = useState<CatalogLookup>({ matches: [], suggestions: [] }); const [product, setProduct] = useState<CatalogProduct | null>(null);
  const [kind, setKind] = useState<"consume" | "waste" | "adjust">("consume");
  const [expirySource, setExpirySource] = useState<"label" | "user" | "estimate" | "unknown">(batch?.expiry_source || "unknown");
  const [flagged, setFlagged] = useState(Boolean(batch?.flagged)); const [expiry, setExpiry] = useState(batch?.expiry || ""); const [searching, setSearching] = useState(false);
  const now = new Date(); const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  useEffect(() => {
    if (mode !== "receive" || productQuery.trim().length < 1) { setLookup({ matches: [], suggestions: [] }); return; }
    let active = true; const timer = window.setTimeout(() => { setSearching(true); api<CatalogLookup>(`/catalog/products?q=${encodeURIComponent(productQuery.trim())}`).then(result => { if (active) setLookup(result); }).catch(error => { if (active) notify(error instanceof Error ? error.message : "Không tìm được danh mục.", true); }).finally(() => { if (active) setSearching(false); }); }, 250);
    return () => { active = false; window.clearTimeout(timer); };
  }, [mode, productQuery, notify]);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); const form = new FormData(event.currentTarget); setBusy(true);
    try {
      if (mode === "receive") {
        if (!product) throw new Error("Vui lòng chọn một thực phẩm trong danh mục."); const source = String(form.get("expiry_source")) as typeof expirySource;
        await api(`/households/${householdId}/inventory/batches`, "POST", { product_id: product.id, quantity: String(form.get("quantity")), unit: String(form.get("unit")), received: String(form.get("received")), expiry: source === "unknown" ? null : String(form.get("expiry")), expiry_source: source, flagged: false, request_key: crypto.randomUUID() }); onSaved("Đã nhập thực phẩm vào kho thành công.");
      } else if (mode === "movement" && batch) {
        const amount = String(form.get("quantity")); const movementReason = String(form.get("reason"));
        await api(`/households/${householdId}/inventory/batches/${batch.id}/movements`, "POST", { product_id: batch.product_id, quantity: amount, unit: batch.base_unit, kind, reason: movementReason, ...(kind === "adjust" ? { expected_version: batch.version } : {}), request_key: crypto.randomUUID() });
        onSaved(kind === "consume" ? "Đã ghi nhận lượng thực phẩm sử dụng." : kind === "waste" ? "Đã ghi nhận thực phẩm bỏ đi." : "Đã cập nhật số lượng kiểm kê.");
      } else if (mode === "review" && batch) {
        const source = String(form.get("expiry_source")) as typeof expirySource;
        await api(`/households/${householdId}/inventory/batches/${batch.id}/review`, "PUT", { expected_version: batch.version, expiry: source === "unknown" ? null : String(form.get("expiry")), expiry_source: source, flagged, reason: String(form.get("reason")), request_key: crypto.randomUUID() }); onSaved("Đã cập nhật thông tin và trạng thái lô hàng.");
      }
    } catch (error) { notify(error instanceof Error ? error.message : "Không thể lưu thay đổi.", true); } finally { setBusy(false); }
  };
  const title = mode === "receive" ? "Nhập thực phẩm mới" : mode === "movement" ? "Cập nhật tồn kho" : "Rà soát thông tin lô";
  return <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><section className="inventory-modal" role="dialog" aria-modal="true" aria-labelledby="inventory-modal-title"><div className="modal-heading"><div><span className="eyebrow">KHO THỰC PHẨM</span><h2 id="inventory-modal-title">{title}</h2><p>{batch ? `${batch.name} · Lô #${batch.id}` : "Ghi nhận thực phẩm mới vào kho gia đình."}</p></div><button className="icon-button" onClick={onClose} aria-label="Đóng"><X size={19} /></button></div>
    <form className="inventory-form" onSubmit={submit}>
      {mode === "receive" && <><label>Tìm thực phẩm trong danh mục<input value={productQuery} onChange={event => { setProductQuery(event.target.value); setProduct(null); }} placeholder="Ví dụ: thịt gà, cà chua, sữa..." required /></label>{searching && <small className="field-hint">Đang tìm trong danh mục...</small>}{(lookup.matches.length ? lookup.matches : lookup.suggestions).length > 0 && <div className="product-options">{(lookup.matches.length ? lookup.matches : lookup.suggestions).map(item => <button type="button" key={item.id} className={`product-option ${product?.id === item.id ? "chosen" : ""}`} onClick={() => { setProduct(item); setProductQuery(item.name); setUnit(item.base_unit); }}><span>{foodEmoji(item.name)}</span><span><b>{item.name}</b><small>{item.category} · Đơn vị chuẩn: {item.base_unit}</small></span><CheckCircle2 size={16} /></button>)}</div>}{product && <div className="selected-product-note"><CheckCircle2 size={15} /> Đã chọn: <b>{product.name}</b></div>}<div className="form-grid"><label>Số lượng<input name="quantity" type="number" min="0.001" step="any" placeholder="Ví dụ: 500" required /></label><label>Đơn vị<select name="unit" value={unit} onChange={event => setUnit(event.target.value)}>{(product?.base_unit === "g" ? [{v:"g",t:"Gram (g)"},{v:"kg",t:"Kilogram (kg)"}] : product?.base_unit === "ml" ? [{v:"ml",t:"Mililit (ml)"},{v:"l",t:"Lít (l)"}] : [{v:"quả",t:"Quả"}]).map(option => <option key={option.v} value={option.v}>{option.t}</option>)}</select></label><label>Ngày nhập<input name="received" type="date" defaultValue={today} max={today} required /></label><label>Nguồn hạn sử dụng<select name="expiry_source" value={expirySource} onChange={event => setExpirySource(event.target.value as typeof expirySource)}><option value="label">Theo nhãn sản phẩm</option><option value="user">Người dùng xác nhận</option><option value="estimate">Ước tính – cần xác minh</option><option value="unknown">Chưa xác định</option></select></label></div>{expirySource !== "unknown" && <label>Hạn sử dụng<input name="expiry" type="date" required /></label>}</>}
      {mode === "movement" && batch && <><div className="movement-summary"><span className="product-emoji">{foodEmoji(batch.name)}</span><div><b>{batch.name}</b><small>Tồn hiện tại: {batch.ticks} {batch.base_unit}</small></div></div><label>Loại thao tác<select value={kind} onChange={event => setKind(event.target.value as typeof kind)}><option value="consume">Đã sử dụng</option><option value="waste">Bỏ đi / hư hỏng</option><option value="adjust">Đối soát tồn thực tế</option></select></label><label>{kind === "adjust" ? "Số lượng thực tế sau kiểm kê" : "Số lượng"}<div className="input-with-unit"><input name="quantity" type="number" min={kind === "adjust" ? "0" : "0.001"} step="any" placeholder={`Nhập theo ${batch.base_unit}`} required /><span>{batch.base_unit}</span></div></label><label>Lý do / ghi chú<input name="reason" minLength={1} maxLength={250} defaultValue="used" required /></label>{kind === "adjust" && <small className="field-hint">Đối soát dùng phiên bản lô hiện tại ({batch.version}) để tránh ghi đè thay đổi đồng thời.</small>}</>}
      {mode === "review" && batch && <><div className="movement-summary"><span className="product-emoji">{foodEmoji(batch.name)}</span><div><b>{batch.name}</b><small>Lô #{batch.id} · Phiên bản {batch.version}</small></div></div><label>Nguồn hạn sử dụng<select name="expiry_source" value={expirySource} onChange={event => setExpirySource(event.target.value as typeof expirySource)}><option value="label">Theo nhãn sản phẩm</option><option value="user">Người dùng xác nhận</option><option value="estimate">Ước tính – cần xác minh</option><option value="unknown">Chưa xác định</option></select></label>{expirySource !== "unknown" && <label>Hạn sử dụng<input name="expiry" type="date" value={expiry} onChange={event => setExpiry(event.target.value)} required /></label>}<label className="check-field"><input type="checkbox" checked={flagged} onChange={event => setFlagged(event.target.checked)} /> Đánh dấu lô cần kiểm tra trước khi sử dụng</label><label>Lý do rà soát<input name="reason" defaultValue="verified" maxLength={250} required /></label></>}
      <div className="modal-actions"><button type="button" className="btn btn-outline" onClick={onClose}>Hủy</button><button className="btn btn-primary" disabled={busy}>{busy ? "Đang lưu..." : "Lưu thay đổi"}<CheckCircle2 size={16} /></button></div>
    </form></section></div>;
}

function AlertsPage({ alerts, onMarkRead }: { alerts: Alert[]; onMarkRead: (alert: Alert) => void }) {
  const [filter, setFilter] = useState("all");
  const filtered = alerts.filter(alert => filter === "all" || (filter === "unread" && !alert.read) || filter === alert.reason);
  const filters = [{ id: "all", label: `Tất cả (${alerts.length})` }, { id: "unread", label: `Chưa đọc (${alerts.filter(a => !a.read).length})` }, { id: "past_date", label: "Quá hạn" }, { id: "due_soon", label: "Sắp đến hạn" }, { id: "verify_expiry", label: "Cần xác minh" }, { id: "flagged", label: "Đã đánh dấu" }];
  return <><PageHeader eyebrow="THEO DÕI VÀ NHẮC NHỞ" title="Thông báo hạn sử dụng" description="Cảnh báo được tính theo quy tắc Backend và trạng thái đọc riêng của tài khoản." /><div className="info-banner"><ShieldCheck size={17} /><span>Quá ngày hạn, còn tối đa 3 ngày, hạn chưa xác minh hoặc lô được đánh dấu. Hạn ước tính cần được kiểm tra trước khi sử dụng.</span></div><div className="filter-tabs">{filters.map(item => <button key={item.id} className={filter === item.id ? "selected" : ""} onClick={() => setFilter(item.id)}>{item.label}</button>)}</div><section className="surface-card alert-page-list">{filtered.length ? filtered.map(alert => <div className="alert-page-row" key={`${alert.batch_id}-${alert.reason}`}><div className={`attention-icon ${alert.reason === "past_date" ? "danger" : "warning"}`}>{alert.reason === "past_date" ? <AlertTriangle size={18} /> : <Clock3 size={18} />}</div><div className="alert-page-copy"><b>{alert.product}</b><span>{alertLabel(alert)} · {alert.expiry ? `Hạn: ${dateLabel(alert.expiry)}` : "Không có ngày hạn xác nhận"}</span></div>{alert.read ? <StatusPill tone="neutral">Đã đọc</StatusPill> : <button className="btn btn-outline btn-small" onClick={() => onMarkRead(alert)}>Đánh dấu đã đọc</button>}</div>) : <EmptyState title="Không có thông báo trong mục này" description="Không tìm thấy cảnh báo phù hợp với bộ lọc đã chọn." action="Xem tất cả" onAction={() => setFilter("all")} />}</section></>;
}
function PageHeader({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) { return <section className="page-heading"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></section>; }
function ComingSoon({ page, onBack }: { page: Page; onBack: () => void }) {
  const details: Record<string, { icon: ReactNode; title: string; description: string; api: string }> = {
    receipts: { icon: <FileImage size={24} />, title: "Quét và xác nhận hóa đơn", description: "Tải ảnh hóa đơn, xem kết quả OCR, chỉnh sửa dòng hàng và xác nhận trước khi nhập kho.", api: "POST /receipts · GET /receipts/{id} · PUT /receipts/{id} · POST /confirm" },
    recipes: { icon: <ChefHat size={24} />, title: "Gợi ý món ăn thông minh", description: "Gợi ý dựa trên tồn kho, khẩu phần, hồ sơ ăn uống và dị ứng của thành viên.", api: "GET /recipes · GET/PUT /me/dietary · POST /recommendations" },
    meals: { icon: <CalendarDays size={24} />, title: "Kế hoạch bữa ăn", description: "Lập lịch bữa ăn theo ngày, người tham gia và số khẩu phần.", api: "GET/POST/PUT/DELETE /meals" },
    groceries: { icon: <ShoppingBasket size={24} />, title: "Danh sách mua sắm", description: "Tính nguyên liệu còn thiếu theo kế hoạch bữa ăn và xác nhận danh sách mua.", api: "GET /groceries · POST /grocery-lists · cập nhật trạng thái mua" },
    reports: { icon: <TrendingDown size={24} />, title: "Thống kê sử dụng và lãng phí", description: "Theo dõi thực phẩm đã nhập, đã sử dụng, điều chỉnh và ghi nhận bỏ đi theo khoảng thời gian.", api: "GET /reports" },
    household: { icon: <Users size={24} />, title: "Hộ gia đình", description: "Quản lý thành viên, mã mời và vai trò chủ hộ. Trang quản lý hộ hiện tại vẫn được giữ nguyên ở Backend.", api: "GET/POST /households · quản lý thành viên và lời mời" },
  };
  const item = details[page];
  return <><PageHeader eyebrow="SMARTFOOD AI" title={pageLabels[page]} description="Không gian chức năng của SmartFood AI." /><div className="coming-card surface-card"><div className="coming-icon">{item.icon}</div><span className="eyebrow">ĐANG TRONG LỘ TRÌNH PHÁT TRIỂN</span><h2>{item.title}</h2><p>{item.description}</p><div className="api-note"><Command size={15} /><span>API nghiệp vụ được ghi nhận trong source: <code>{item.api}</code></span></div><button className="btn btn-primary" onClick={onBack}>Quay lại Dashboard <ChevronRight size={16} /></button></div></>;
}
function Toast({ message, error }: { message: string; error?: boolean }) { return <div className={`toast ${error ? "toast-error" : ""}`} role="status"><span>{error ? <AlertTriangle size={17} /> : <CheckCircle2 size={17} />}</span>{message}</div>; }
